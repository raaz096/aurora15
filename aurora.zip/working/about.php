<?php include 'ae_header.php';?>
<title>About | Aurora`15</title>

			<center>
				<a href="index.php"><button><strong>Home</strong></button></a>
				<a href="about.php"><button><h3><strong>About</strong></h3></button></a>
				<a href="events.php"><button><strong>Events</strong></button></a>
				<a href="team.php"><button><strong>Team</strong></h3></button></a>
				<a href="gallery.php"><button><strong>Gallery</strong></button></a><br>
				<div class="col span_1_of_2">
	 			<center><h3>AURORA gets its name from Aurora- a natural electrical phenomenon characterized by the appearance of streamers of reddish or greenish light in the sky, especially near the northern or southern magnetic pole called aurora borealis or aurora australis.</h3></center>
	  		</div>
				
				
			<div class="col span_1_of_3">
	 			<section class="rw-wrapper">
				<h2 class="rw-sentence">
				&nbsp;&nbsp;&nbsp;&nbsp;
				<div class="rw-words rw-words-1">
					<span><b>AURORA`15</b></span>
					<span>ENSNARING THY <br>SENSE ...</span>
					<span>20th - 22nd, Feb</span>
					<span>The Pronites</span>
					<span>CORNA - Rock Band<br>Competition</span>
					<span>PARIVESH - Fashion <br>Extravaganza</span>
			<?php include 'ae_footer.php';?>
