<?php include 'rest-header.php';?>
		<title>Aurora Idol | Events | Aurora`15</title>
		<div class="md-modal md-effect-1" id="modal-1">
      <div class="md-content">
        <h2>Rules</h2>
        <div>
          <p>Coming Soon ....</p>
          
          <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
    <div class="md-modal md-effect-2" id="modal-2">
      <div class="md-content">
        <h2>Timeline</h2>
        <div>
          <p>Coming Soon ....</p>
          <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
    <div class="md-modal md-effect-3" id="modal-3">
      <div class="md-content">
        <h2>Contact</h2>
        <div>
          <p>Coming Soon ....</p>
            <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
   
		<div class="container">
			<header>
				<?php include 'rest-navigation.php';?>
				<h1>Aurora Idol <span><br>Recreating the 20’s nostalgia with the euphonious and
tranquilizing voices of the dexterous singers, Aurora
idol is ready to scout for the emerging Indian Idol or
the Amul star Voice of India! So here we haul the
opportunity to all the young guns to become the next
Arijit Singh or Shreya Ghoshal who with their salubrious
voices emerged as the front runners of the music
industry in 20’s! </span></h1>
			</header>
			<div class="main clearfix">
				<div class="column">
					<br><br><br><br><br>
					<button class="md-trigger" data-modal="modal-1">Rules</button><br>
					<button class="md-trigger" data-modal="modal-2">Timeline</button><br>
					<button class="md-trigger" data-modal="modal-3">Contact</button>
				</div>
				<div style="border-left:medium #ffffff double; height:300px; margin-left:20%;" />
				<div class="column_mid">
					<section class="rw-wrapper">
						<h3 class="rw-sentence">
						<div class="rw-words rw-words-1" style="margin-left:20%;">
							<span>Aurora Idol </span>
							<span>Mr. n Ms. Aurora</span>
							<span>Phoenix </span>
							<span>Treasure Hunt </span>
							<span> Street Play </span>
							<span>Laugh Out Loud</span>
						</div>
						</h3>
					</section>
					<h2> For every musical soul,
it’s an event to rejuvenate life with some of the scintillating
monophonic performances by honey soothe voices from
colleges all across the country. From sur of sa to rang of re,
ladies and gentlemen put your hearts at piece and enjoy the
alpana of great music.</h2>
				</div>
				<?php include 'rest-footer.php';?>
