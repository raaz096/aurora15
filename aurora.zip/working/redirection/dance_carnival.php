<?php include 'rest-header.php';?>
		<title>Dance Carival | Events | Aurora`15</title>
		<div class="md-modal md-effect-1" id="modal-1">
      <div class="md-content">
        <h2>Nupur</h2>
        <div>
          <p>Coming Soon ....</p>
          
          <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
    <div class="md-modal md-effect-2" id="modal-2">
      <div class="md-content">
        <h2>Dancing Jodi</h2>
        <div>
          <p>Coming Soon ....</p>
          <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
    <div class="md-modal md-effect-3" id="modal-3">
      <div class="md-content">
        <h2>Just Do It</h2>
        <div>
          <p>Coming Soon ....</p>
            <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
    <div class="md-modal md-effect-1" id="modal-4">
      <div class="md-content">
        <h2>Syncro Funk</h2>
        <div>
          <p>Coming Soon ....</p>
            <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
    <div class="md-modal md-effect-2" id="modal-5">
      <div class="md-content">
        <h2>Sanskriti</h2>
        <div>
          <p>Coming Soon ....</p>
            <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
    <div class="md-modal md-effect-3" id="modal-6">
      <div class="md-content">
        <h2>HeadSpin</h2>
        <div>
          <p>Coming Soon ....</p>
            <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
    <div class="md-modal md-effect-1" id="modal-7">
      <div class="md-content">
        <h2>Rules</h2>
        <div>
          <p>Coming Soon ....</p>
            <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
    <div class="md-modal md-effect-2" id="modal-8">
      <div class="md-content">
        <h2>Timeline</h2>
        <div>
          <p>Coming Soon ....</p>
            <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
    <div class="md-modal md-effect-3" id="modal-9">
      <div class="md-content">
        <h2>Contact</h2>
        <div>
          <p>Coming Soon ....</p>
            <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
   
		<div class="container">
			<header>
				<?php include 'rest-navigation.php';?>
				<h1>Dance Carnival <span><br>The entire world’s a stage.Bringing back the 20’s
extravaganza, the era wherein contests like Dance
India Dance and India’s dancing superstar created a
whiz bang and enkindled dancing sensations like Prince
and Dharmesh Sir. So are you willing to show your
masala on the stage? Or set the stage on fire with the
colors and mesmerize us with your latkas, jhatkas &amp;
thumkas. Bollywood ishtyle!</span></h1>
					<button class="md-trigger" data-modal="modal-1">Nupur</button>
					<button class="md-trigger" data-modal="modal-2">Dancing Jodi</button>
					<button class="md-trigger" data-modal="modal-3">Just Do It</button>
					<button class="md-trigger" data-modal="modal-4">Synchro Funk</button>
					<button class="md-trigger" data-modal="modal-5">Sanskriti</button>
					<button class="md-trigger" data-modal="modal-6">HeadSpin</button>
					
							</header>
			<div class="main clearfix">
				<div class="column">
					<br><br><br><br><br>
					<button class="md-trigger" data-modal="modal-7">Rules</button><br>
					<button class="md-trigger" data-modal="modal-8">Timeline</button><br>
					<button class="md-trigger" data-modal="modal-9">Contact</button>
				</div>
				<div style="border-left:medium #ffffff double; height:300px; margin-left:20%;" />
				<div class="column_mid">
					<section class="rw-wrapper">
						<h3 class="rw-sentence">
						<div class="rw-words rw-words-1" style="margin-left:20%;">
							<span>Dancing Jodi</span>
							<span>Nupur</span>
							<span>Synchro Funk </span>
							<span>Freaky Freestyle</span>
							<span>Just Do It </span>
							<span>Prop and Dance</span>
						</div>
						</h3>
					</section>
					<h2>Dance carnival is just the thing for
you magnificent dancers! Set the stage on fire with your
eloquent flair and dexterity. DANCE CARNIVAL is the ultimate
platform wherein you can showcase your talent and spellbound
the audience with your dexterity!</h2>
				</div>
				<?php include 'rest-footer.php';?>