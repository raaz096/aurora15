<?php include 'rest-header.php';?>
		<title>Mr. n Ms. Aurora | Events | Aurora`15</title>
		<div class="md-modal md-effect-1" id="modal-1">
      <div class="md-content">
        <h2>Rules</h2>
        <div>
          <p>Coming Soon ....</p>
          
          <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
    <div class="md-modal md-effect-2" id="modal-2">
      <div class="md-content">
        <h2>Timeline</h2>
        <div>
          <p>Coming Soon ....</p>
          <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
    <div class="md-modal md-effect-3" id="modal-3">
      <div class="md-content">
        <h2>Contact</h2>
        <div>
          <p>Coming Soon ....</p>
            <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
		
		<div class="container">
			<header>
				<?php include 'rest-navigation.php';?>
				<h1>Mr. n Ms. Aurora <span><h2>If superiority is a curse, then the cursed
shall rise.</h2>
The race to earn the coveted tag and make
heads turn for days begun. MnM is the
irrevocable search for the best with the
pleasing aura in personality. It is the
personality hunt contest of Aurora where
the titles of Mr and Ms Aurora find their
suitable bearer.</span></h1>
				
			</header>
			<div class="main clearfix">
				<div class="column">
					<br><br><br><br><br>
					<button class="md-trigger" data-modal="modal-1">Rules</button><br>
					<button class="md-trigger" data-modal="modal-2">Timeline</button><br>
					<button class="md-trigger" data-modal="modal-3">Contact</button>
				</div>
				<div style="border-left:medium #ffffff double; height:300px; margin-left:20%;" />
				<div class="column_mid">

					<section class="rw-wrapper">
						<h3 class="rw-sentence">
						<div class="rw-words rw-words-1" style="margin-left:20%;">
							<span>Mr. n Ms. Aurora</span>
							<span>Phoenix </span>
							<span>Treasure Hunt </span>
							<span> Street Play </span>
							<span>Laugh Out Loud</span>
							<span>Aurora Idol </span>
						</div>
						</h3>
					</section>
					<h2>Come participate in Mr and Miss Aurora and drench the world
with your awesomeness.
An ultimate festival entertainer, it looks for confidence, talent,
originality and sense of humour. The winners are crowned
reigning king and queen of Aurora.
Be a part of the battle to become the next iconic girl and
charming boy of Aurora`15.</h2>
				</div>
<?php include 'rest-footer.php';?>
