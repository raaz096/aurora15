<?php
echo <<< EOT
				<div class="column_end">
						<h1>&nbsp;&nbsp;Updates</h1>
						<section class="rw-wrapper1">
						<h3 class="rw-sentence1">
						<div class="rw-words rw-words-1">
							<span>Android App launching on 20th January 2015.</span>
							<span>First Round of Snaptrap is starting from 16th January. </span>
							<span>I. Me. MySelfie is starting tonight on facebook page.</span>
							<span>Parivesh auditions are started in OAT for institute student only. </span>
							<span>Dance Carnival rule book will be launching soon.</span>
							<span>Auditions for Aurora Idol is starting soon.</span>
						</div>
						</h3>
					</section>
				</div>
			</div>
			<h1>Events</h1>
						<center>
						<b>
						<a href="../redirection/corna.php"><button>Corna</button></a>
						<a href="../redirection/parivesh.php"><button>Parivesh</button></a>
						<a href="../redirection/dance_carnival.php"><button>Dance Carnival</button></a>
						<a href="../redirection/aurora_idol.php"><button>Aurora Idol</button></a>
						<a href="../redirection/art_mela.php"><button>Art Mela</button></a>
						<a href="../redirection/mnm.php"><button>Mr. N Ms. Aurora</button></a>
						<a href="../redirection/streetplay.php"><button>Street Play</button></a>
						<a href="../redirection/lol.php"><button>Laugh Out Loud</button></a>
						<a href="../redirection/treasure_hunt.php"><button>Treasure Hunt</button></a>
						<a href="../redirection/phoenix.php"><button>Phoenix</button></a></b></center>
						<br>
						<center><h2>&copy; AURORA`15 - <em>Ensnaring Thy Senses </em>...</h2></center>
						
		</div><!-- /container -->
		<div class="md-overlay"></div><!-- the overlay element -->

		<!-- classie.js by @desandro: https://github.com/desandro/classie -->
		<script src="js/classie.js"></script>
		<script src="js/modalEffects.js"></script>

		<!-- for the blur effect -->
		<!-- by @derSchepp https://github.com/Schepp/CSS-Filters-Polyfill -->
		<script>
			// this is important for IEs
			var polyfilter_scriptpath = '/js/';
		</script>
		<script src="js/cssParser.js"></script>
		<script src="js/css-filters-polyfill.js"></script>
	</body>
</html>
EOT;
?>


