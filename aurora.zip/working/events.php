<?php include 'ae_header.php';?>
<title>Events | Aurora`15</title>

			<center>
				<a href="index.php"><button><strong>Home</strong></button></a>
				<a href="about.php"><button><strong>About</strong></button></a>
				<a href="events.php"><button><h3><strong>Events</strong></h3></button></a>
				<a href="team.php"><button><strong>Team</strong></h3></button></a>
				<a href="gallery.php"><button><strong>Gallery</strong></button></a><br>
				<div class="col span_1_of_2">
	 			<center><h3>Grab the opportunity to experience the entire enticement and necromancy of the 20‟s blended with a wonderful journey of three days filled with really galvanizing, fun filled & beguiling events with Aurora`15! Feel the adrenaline rush and Ensnare your senses!</h3></center>
	  		</div>
			<div class="col span_1_of_3">
	 			<section class="rw-wrapper">
				<h2 class="rw-sentence">
				&nbsp;&nbsp;&nbsp;&nbsp;
				<div class="rw-words rw-words-1">
					<span><b>Dance Carnival</b></span>
		            <span><b>Aurora Idol</b></span>
		            <span><b>Mr. n Ms. Aurora</b></span>
		            <span><b>Laugh Out Loud</b></span>
		            <span><b>Treasure Hunt</b></span>
		            <span><b>Street Play</b></span>
		            <?php include 'ae_footer.php';?>

				