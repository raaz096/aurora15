<?php include 'main-header.php';?>
			<section class="main">
			
				<ul class="ch-grid">
				<h2><strong>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Coordinators</strong> </h2>
					<li>

						<div class="ch-item">	
							<div class="ch-info">
								<h3 style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 100%;">Hashmeet Sikka</h3>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 70%;"><a href="mailto:someone@example.com?Subject=Hello%20again" target="_top"><font color="#ffffff">hssikka.hs@gmail.com</font></a></p>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 90%;"> 9541163791
										<br>
								
								<a href="#"><img src="images/fb.png" width="40" height="40"> </a>
								<a href="#"><img src="images/in.png" width="40" height="40"> </a>
									</p >
							</div>
							<div class="ch-thumb ch-img-1"></div>
						</div>
					</li>
					<li>
						<div class="ch-item">	
							<div class="ch-info">
								<h3 style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 100%;">Sunny Singh</h3>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 70%;"><a href="mailto:someone@example.com?Subject=Hello%20again" target="_top"><font color="#ffffff">smartsn123@gmail.com</font></a></p>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 90%;"> 9479874744
										<br>
								
								<a href="#"><img src="images/fb.png" width="40" height="40"> </a>
								<a href="#"><img src="images/in.png" width="40" height="40"> </a>
									</p >
							</div>
							<div class="ch-thumb ch-img-2"></div>
						</div>
					</li>
					</ul>
					<ul class="ch-grid">
					<li>
						<div class="ch-item">	
							<div class="ch-info">
								<h3 style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 100%;">Sahil Singhal</h3>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 70%;"><a href="mailto:someone@example.com?Subject=Hello%20again" target="_top"><font color="#ffffff">sahilsinghal49@gmail.com</font></a></p>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 90%;"> 7747023123
										<br>
								
								<a href="#"><img src="images/fb.png" width="40" height="40"> </a>
								<a href="#"><img src="images/in.png" width="40" height="40"> </a>
									</p >
							</div>
							<div class="ch-thumb ch-img-3"></div>
						</div>
					</li>
					<li>
						<div class="ch-item">	
							<div class="ch-info">
								<h3 style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 100%;">Ayush Agarwal</h3>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 70%;"><a href="mailto:someone@example.com?Subject=Hello%20again" target="_top"><font color="#ffffff">ayushagarwal733@gmail.com</font></a></p>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 90%;"> 942575588
										<br>
								
								<a href="#"><img src="images/fb.png" width="40" height="40"> </a>
								<a href="#"><img src="images/in.png" width="40" height="40"> </a>
									</p >
							</div>
							<div class="ch-thumb ch-img-4"></div>
						</div>
					</li><li>
						<div class="ch-item">	
							<div class="ch-info">
								<h3 style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 100%;">Mukesh Chaturvedi</h3>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 70%;"><a href="mailto:someone@example.com?Subject=Hello%20again" target="_top"><font color="#ffffff">aakashkh284@gmail.com</font></a></p>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 90%;"> 8236079428
										<br>
								
								<a href="#"><img src="images/fb.png" width="40" height="40"> </a>
								<a href="#"><img src="images/in.png" width="40" height="40"> </a>
									</p >
							</div>
							<div class="ch-thumb ch-img-5"></div>
						</div>
					</li>
				</ul>
				
				<ul class="ch-grid">
								<h2><strong>Event Management</strong> </h2>

					<li>
						<div class="ch-item">	
							<div class="ch-info">
								<h3 style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 100%;">Aakash Khandelwal</h3>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 70%;"><a href="mailto:someone@example.com?Subject=Hello%20again" target="_top"><font color="#ffffff">aakashkh284@gmail.com</font></a></p>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 90%;"> 9406577543
										<br>
								
								<a href="#"><img src="images/fb.png" width="40" height="40"> </a>
								<a href="#"><img src="images/in.png" width="40" height="40"> </a>
									</p >
							</div>
							<div class="ch-thumb ch-img-6"></div>
						</div>
					</li>
					<li>
						<div class="ch-item">	
							<div class="ch-info">
								<h3 style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 100%;">Ayush Agrawal</h3>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 70%;"><a href="mailto:someone@example.com?Subject=Hello%20again" target="_top"><font color="#ffffff">9ayucool@gmail.com</font></a></p>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 90%;"> 9407202513
										<br>
								
								<a href="#"><img src="images/fb.png" width="40" height="40"> </a>
								<a href="#"><img src="images/in.png" width="40" height="40"> </a>
									</p >
							</div>
							<div class="ch-thumb ch-img-7"></div>
						</div>
					</li><li>
						<div class="ch-item">	
							<div class="ch-info">
								<h3 style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 100%;">Amit Kumar</h3>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 70%;"><a href="mailto:someone@example.com?Subject=Hello%20again" target="_top"><font color="#ffffff">akumar4850@gmail.com</font></a></p>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 90%;"> 9406580936
										<br>
								
								<a href="#"><img src="images/fb.png" width="40" height="40"> </a>
								<a href="#"><img src="images/in.png" width="40" height="40"> </a>
									</p >
							</div>
							<div class="ch-thumb ch-img-8"></div>
						</div>
					</li>
					<li>
						<div class="ch-item">	
							<div class="ch-info">
								<h3 style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 100%;">Nikhil Mehandiratta</h3>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 70%;"><a href="mailto:someone@example.com?Subject=Hello%20again" target="_top"><font color="#ffffff">mehandirattanikhil@gmail.com</font></a></p>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 90%;"> 8989216761
										<br>
								
								<a href="#"><img src="images/fb.png" width="40" height="40"> </a>
								<a href="#"><img src="images/in.png" width="40" height="40"> </a>
									</p >
							</div>
							<div class="ch-thumb ch-img-9"></div>
						</div>
					</li>
					<li>
						<div class="ch-item">	
							<div class="ch-info">
								<h3 style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 100%;">Yugarshi Shashwat</h3>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 70%;"><a href="mailto:someone@example.com?Subject=Hello%20again" target="_top"><font color="#ffffff">yugarshis36@gmail.com</font></a></p>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 90%;"> 9479810343
										<br>
								
								<a href="#"><img src="images/fb.png" width="40" height="40"> </a>
								<a href="#"><img src="images/in.png" width="40" height="40"> </a>
									</p >
							</div>
							<div class="ch-thumb ch-img-10"></div>
						</div>
					</li>
					<li>
						<div class="ch-item">	
							<div class="ch-info">
								<h3 style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 100%;">Anshika Singh</h3>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 70%;"><a href="mailto:someone@example.com?Subject=Hello%20again" target="_top"><font color="#ffffff">aashuanshika1994@gmail.com</font></a></p>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 90%;"> 9826662062
										<br>
								
								<a href="#"><img src="images/fb.png" width="40" height="40"> </a>
								<a href="#"><img src="images/in.png" width="40" height="40"> </a>
									</p >
							</div>
							<div class="ch-thumb ch-img-11"></div>
						</div>
					</li><li>
						<div class="ch-item">	
							<div class="ch-info">
								<h3 style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 100%;">Smriti Raj Srivastava</h3>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 70%;"><a href="mailto:someone@example.com?Subject=Hello%20again" target="_top"><font color="#ffffff">smritiraj55@gmail.com</font></a></p>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 90%;"> 9479675675
										<br>
								
								<a href="#"><img src="images/fb.png" width="40" height="40"> </a>
								<a href="#"><img src="images/in.png" width="40" height="40"> </a>
									</p >
							</div>
							<div class="ch-thumb ch-img-12"></div>
						</div>
					</li>
					
					</ul>
					<!--
					<ul class="ch-grid">
					<li>
						<div class="ch-item">	
							<div class="ch-info">
								<h3 style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 100%;">Hashmeet Sikka</h3>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 70%;"><a href="mailto:someone@example.com?Subject=Hello%20again" target="_top"><font color="#ffffff">aakashkh284@gmail.com</font></a></p>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 90%;"> 9406577543
										<br>
								
								<a href="#"><img src="images/fb.png" width="40" height="40"> </a>
								<a href="#"><img src="images/in.png" width="40" height="40"> </a>
									</p >
							</div>
							<div class="ch-thumb ch-img-10"></div>
						</div>
					</li>
				</ul>

					-->
					<ul class="ch-grid">
									<h2><strong>Marketing and Public Relations</strong> </h2>

					<li>
						<div class="ch-item">	
							<div class="ch-info">
								<h3 style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 100%;">Shantanu Srivastava</h3>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 70%;"><a href="mailto:someone@example.com?Subject=Hello%20again" target="_top"><font color="#ffffff">shan_mbic@rediffmail.com</font></a></p>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 90%;"> 8989101730
										<br>
								
								<a href="#"><img src="images/fb.png" width="40" height="40"> </a>
								<a href="#"><img src="images/in.png" width="40" height="40"> </a>
									</p >
							</div>
							<div class="ch-thumb ch-img-13"></div>
						</div>
					</li>
					<li>
						<div class="ch-item">	
							<div class="ch-info">
								<h3 style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 100%;">Shreya Lohani</h3>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 70%;"><a href="mailto:someone@example.com?Subject=Hello%20again" target="_top"><font color="#ffffff">shreyalohani21@gmail.com</font></a></p>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 90%;"> 9425737316
										<br>
								
								<a href="#"><img src="images/fb.png" width="40" height="40"> </a>
								<a href="#"><img src="images/in.png" width="40" height="40"> </a>
									</p >
							</div>
							<div class="ch-thumb ch-img-14"></div>
						</div>
					</li>		
					</ul>
				<ul class="ch-grid">
									<h2><strong>Promotion</strong> </h2>

					<li>
						<div class="ch-item">	
							<div class="ch-info">
								<h3 style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 100%;">Rohit Nimiya</h3>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 70%;"><a href="mailto:someone@example.com?Subject=Hello%20again" target="_top"><font color="#ffffff">rohitnimiya@gmail.com</font></a></p>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 90%;"> 9074443244
										<br>
								
								<a href="#"><img src="images/fb.png" width="40" height="40"> </a>
								<a href="#"><img src="images/in.png" width="40" height="40"> </a>
									</p >
							</div>
							<div class="ch-thumb ch-img-15"></div>
						</div>
					</li>
					<li>
						<div class="ch-item">	
							<div class="ch-info">
								<h3 style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 100%;">Sachin Singh</h3>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 70%;"><a href="mailto:someone@example.com?Subject=Hello%20again" target="_top"><font color="#ffffff">sachinsingh.iiitm@gmail.com</font></a></p>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 90%;"> 9479636711
										<br>
								
								<a href="#"><img src="images/fb.png" width="40" height="40"> </a>
								<a href="#"><img src="images/in.png" width="40" height="40"> </a>
									</p >
							</div>
							<div class="ch-thumb ch-img-16"></div>
						</div>
					</li><li>
						<div class="ch-item">	
							<div class="ch-info">
								<h3 style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 100%;">Raunak Khemka</h3>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 70%;"><a href="mailto:someone@example.com?Subject=Hello%20again" target="_top"><font color="#ffffff">raunak012@gmail.com</font></a></p>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 90%;"> 8234834724
										<br>
								
								<a href="#"><img src="images/fb.png" width="40" height="40"> </a>
								<a href="#"><img src="images/in.png" width="40" height="40"> </a>
									</p >
							</div>
							<div class="ch-thumb ch-img-17"></div>
						</div>
					</li>
					</ul>
						<ul class="ch-grid">
									<h2><strong>Web and Design</strong> </h2>
										<li>
							<div class="ch-item">	
							<div class="ch-info">
								<h3 style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 100%;">Aakash Khandelwal</h3>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 70%;"><a href="mailto:someone@example.com?Subject=Hello%20again" target="_top"><font color="#ffffff">aakashkh284@gmail.com</font></a></p>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 90%;"> 9406577543
										<br>
								
								<a href="#"><img src="images/fb.png" width="40" height="40"> </a>
								<a href="#"><img src="images/in.png" width="40" height="40"> </a>
									</p >
							</div>
							<div class="ch-thumb ch-img-18"></div>
						</div>
					</li>

					<li>
						<div class="ch-item">	
							<div class="ch-info">
								<h3 style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 100%;">Krishna Kishore</h3>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 70%;"><a href="mailto:someone@example.com?Subject=Hello%20again" target="_top"><font color="#ffffff">krishnakishore.jmj@gmail.com </font></a></p>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 90%;"> 9406577543
										<br>
								
								<a href="#"><img src="images/fb.png" width="40" height="40"> </a>
								<a href="#"><img src="images/in.png" width="40" height="40"> </a>
									</p >
							</div>
							<div class="ch-thumb ch-img-19"></div>
						</div>
					</li>
						
						<li>
						<div class="ch-item">	
							<div class="ch-info">
								<h3 style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 100%;">Mohit Joshi</h3>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 70%;"><a href="mailto:someone@example.com?Subject=Hello%20again" target="_top"><font color="#ffffff">animusmojo@gmail.com</font></a></p>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 90%;">9917996715
										<br>
								
								<a href="#"><img src="images/fb.png" width="40" height="40"> </a>
								<a href="#"><img src="images/in.png" width="40" height="40"> </a>
									</p >
							</div>
							<div class="ch-thumb ch-img-20"></div>
						</div>
					</li>
					<li>
						<div class="ch-item">	
							<div class="ch-info">
								<h3 style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 100%;">Jyoti Patel</h3>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 70%;"><a href="mailto:someone@example.com?Subject=Hello%20again" target="_top"><font color="#ffffff">jyotipatel203@gmail.com </font></a></p>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 90%;"> 9009676678
										<br>
								
								<a href="#"><img src="images/fb.png" width="40" height="40"> </a>
								<a href="#"><img src="images/in.png" width="40" height="40"> </a>
									</p >
							</div>
							<div class="ch-thumb ch-img-21"></div>
						</div>
					</li>
					</ul>
					<ul class="ch-grid">
									<h2><strong>Infrastructure</strong> </h2>

					<li>
						<div class="ch-item">	
							<div class="ch-info">
								<h3 style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 100%;">Vishal Rajwar</h3>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 70%;"><a href="mailto:someone@example.com?Subject=Hello%20again" target="_top"><font color="#ffffff">vraj.144@gmail.com</font></a></p>
								<p style="font-family: 'Merienda', cursive; font-weight: 800; font-size: 90%;"> 7804873787
										<br>
								
								<a href="#"><img src="images/fb.png" width="40" height="40"> </a>
								<a href="#"><img src="images/in.png" width="40" height="40"> </a>
									</p >
							</div>
							<div class="ch-thumb ch-img-22"></div>
						</div>
					</li>
				</ul>
			</section>
			
        </div>
    </body>
</html>