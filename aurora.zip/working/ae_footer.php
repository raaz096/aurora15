<?php
echo <<< EOT
</div>
				</h2>
				</section>
	  		</div>
	  		
			<div class="col span_2_of_3">
	 			<br><br>
	 			<h2>
	 			<strong>
	 			
	 			<a href="redirection/corna.php"><button><strong>Corna</strong></button></a>
						<a href="redirection/parivesh.php"><button><strong>Parivesh</strong></button></a>
						<a href="redirection/dance_carnival.php"><button><strong>Dance Carnival</strong></button></a>
						<a href="redirection/phoenix.php"><button><strong>Phoenix</strong></button></a>	
						<a href="redirection/treasure_hunt.php"><button><strong>Treasure Hunt</strong></button></a>
						<a href="redirection/art_mela.php"><button><strong>Art Mela</strong></button></a>
						<a href="redirection/aurora_idol.php"><button><strong>Aurora Idol</strong></button></a>
						<a href="redirection/streetplay.php"><button><strong>Street Play</strong></button></a>
						<a href="redirection/lol.php"><button><strong>LoL</strong></button></a>
						<a href="redirection/mnm.php"><button><strong>Mr. n Ms. Aurora</strong></button></a>
						</h2> <br> 
										

	  		</div>
	  		<div class="col span_1_of_2">
	 			<center><h2><b>&copy; AURORA`15 - <em>Ensnaring Thy Senses </em>...</b></h2></center>
	  		</div>
				
</div> 

	</div>
<script type='text/javascript' src='http://bright.acid.themevillage.net/wp-content/themes/acid/js/libs.js'></script>
<script type='text/javascript' src='http://bright.acid.themevillage.net/wp-content/themes/acid/js/app.js'></script>
</body>
</html>
EOT;
?>
 