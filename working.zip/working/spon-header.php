<?php
echo <<< EOT
<!DOCTYPE html>
<html lang="en">
    <head>
		<meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		<meta name="viewport" content="width=device-width, initial-scale=1.0"> 
		<title>Sponsers | Aurora`15</title>
        <meta name="description" content="Circle Hover Effects with CSS Transitions" />
        <meta name="keywords" content="circle, border-radius, hover, css3, transition, image, thumbnail, effect, 3d" />
        <meta name="author" content="Codrops" />
        <link rel="shortcut icon" href="images/favicon.ico"> 
        <link rel="stylesheet" type="text/css" href="css/demo.css" />
		<link rel="stylesheet" type="text/css" href="css/common.css" />
				<link href='http://fonts.googleapis.com/css?family=Droid+Sans' rel='stylesheet' type='text/css'>

		<link href='http://fonts.googleapis.com/css?family=Merienda' rel='stylesheet' type='text/css'>
        <link rel="stylesheet" type="text/css" href="css/style3.css" />
		<script src="js/jquery.js" type="text/javascript"></script>
		<script src="js/portfolio.js" type="text/javascript"></script>
		<script src="js/init.js" type="text/javascript"></script>
		<link href='http://fonts.googleapis.com/css?family=Open+Sans:300,700' rel='stylesheet' type='text/css' />
		<script type="text/javascript" src="js/modernizr.custom.79639.js"></script> 
		<!--[if lte IE 8]><style>.main{display:none;} .support-note .note-ie{display:block;}</style><![endif]-->
		<style type="text/css">
			
			h1{
			  text-align: center; 
			  font-family: 'Droid Sans', sans-serif; 
			  font-weight: 1000%; 
			  font-size: 250%;
			  padding-top: 20px;
				}
		 h3{
	font-style: italic;
	margin: 0;
	padding: 15px 0 5px 0;
	color: white;
			  text-align: center; 
			  font-family: 'Droid Sans', sans-serif; 
			  font-weight: 1000; 
			  font-size: 120%;
			  padding-top: 10px;
			}
			h2{
	font-style: italic;
	margin: 0;
	padding: 15px 0 5px 0;
	color: white;
			  text-align: center; 
			  font-family: 'Droid Sans', sans-serif; 
			  font-weight: 1000; 
			  font-size: 250%;
			  padding-top: 20px;
			}
			p, h4,  h6, li, button{
			  font-family: 'Merienda', cursive; 
			  font-weight: 250%; 
			  font-size: 100%;
			  text-align: center;

			}
			
			button {
	padding: 0.6em 1.2em;
background: #95a5a6;
	border-color: #bdc3c7;
		color: #000;
font-family: 'Droid Sans', sans-serif;
	font-size: 1em;
	letter-spacing: 1px;
	text-transform: uppercase;
	cursor: pointer;
	display: inline-block;
	margin: 3px 2px;
	border-radius: 2px;
			  font-family: 'Droid Sans', sans-serif;
			  font-weight: 250%; 
			  font-size:70%;
			  text-align: center;

}


#section {
    width:10%;
    height:10%;
    float:left;
    margin-left :7%;
	margin-top: 3%;	 	 
}
		
		#section_right {
    width:10%;
    float:right;
    height:10%;
    margin-right :8%;
	margin-top: 2%;	 	 
}
		

button:hover {
	background: #bdc3c7;
}


		</style>
    </head>

    <body>
        <div class="container">
		
           
	<div id="section"><img src="images/logo.png" width="110%" height="80%"/></div>
		<div id="section_right"><img src="images/iiitmlogo.png" width="80%" height="40%"/></div>
			
			<header>
				
				<a href="index.php"><button><strong>Home</strong></button></a>
				<a href="about.php"><button><strong>About</strong></button></a>
				<a href="events.php"><button><strong>Events</strong></button></a>
				<a href="team.php"><button><strong>Team</strong></button></a>
				<a href="sponsers.php"><button><h3><strong>Sponsors</strong></h3></button></a>
				<a href="gallery.php"><button><strong>Gallery</strong></button></a>
				<br><br><br>
				
			</header>
EOT;
?>


