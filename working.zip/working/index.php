<!DOCTYPE html>
<html lang="en-US" class="no-js">
<!-- ************ HEAD START ******************************** -->
<head>
<meta charset="UTF-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>AURORA`15</title>
<!--favicon-->
<link rel="icon" type="image/ico" href="images/favicon.ico"/>
<!-- ******************************** SCRITPS ******************************** -->
<script> document.documentElement.className = 'js'; </script>
<!--[if lt IE 9]>
<script src="http://bright.acid.themevillage.net/wp-content/themes/acid/js/ie/explorer.js" type="text/javascript"></script>
<link rel="stylesheet" href="http://bright.acid.themevillage.net/wp-content/themes/acid/css/ie.css">
<![endif]-->
<script> ACID_OPTIONS_CONFIG = {"footer_toggle":true,"auto_initial_scroll":true,"blinking_arrow":true}; </script>
<!-- ********************** LINKS and META Tags ******************************** -->
<meta name='robots' content='noindex,follow'/>
<link href='http://fonts.googleapis.com/css?family=Droid+Sans' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Merienda' rel='stylesheet' type='text/css'>
<link href='http://fonts.googleapis.com/css?family=Yanone+Kaffeesatz:400,700' rel='stylesheet' type='text/css'>
<link rel='stylesheet' id='style-css' href='css/style.min.css' type='text/css' media='all'/>
<link rel='stylesheet' id='pure-social-icons-css' href='css/social.css' type='text/css' media='all'/>
<link rel='stylesheet' id='pure-social-icons-css' href='css/navigation.css' type='text/css' media='all'/>
<!-- ***************************************** SCRIPTS ************************ -->
<script type='text/javascript' src='js/jquery1.11.1.js'></script>
<script type='text/javascript' src='js/jquery-migrate.min.js'></script>
<!-- ******************* INTERNAL STYLING START ***************** -->
<style type="text/css" id="custom-background-css">body.custom-background{background-image:url('images/diagmonds.png');background-repeat:repeat;background-position:top left;background-attachment:fixed;}</style>
<style type="text/css">
	@media screen and (max-width: 720px) {
    .large-header {
        display: none;
    }
}
</style>
<link rel="stylesheet" type="text/css" href="css/component.css" />
<!-- ******************************** INTERNAL STYLING END ********************************-->
</head>
<!-- ******************************** HEAD-END ********************************-->
<!-- ******************************** BODY START ********************************-->
<body class="home paged page page-id-199 page-template page-template-templatespage-one-page-layout-php custom-background paged-3 page-paged-3 sidebar-disabled">
<!--******************************** MAIN DIV START ********************************-->
<div id="page" class="hfeed site">
<!--******************************** HEADER ********************************-->
	<header class="site-header cf" role="banner">
		<a id="logo" class="alpha site-title  image" href="index.php" title="AURORA`15" rel="home">
		<img src="images/logo.png" width="40" height="40" style="margin-top:10%"; />
<!-- <img class="site-logo" src="images/logo.png" alt="Aurora`15"/> -->
		</a>
		<div class="site-header-inner">
			<nav id="navigation" role="navigation" class="site-navigation">
				<div class="sf-container">
					<ul id="menu-main-menu" class="sf-menu">
						<li id="menu-item-389" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-389"><a href="about.php" target="_self">About</a></li>
						<li id="menu-item-383" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-383"><a href="events.php" target="_self">Events</a></li>
						<li id="menu-item-389" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-389"><a href="team.php" target="_self">Team</a></li>
						<li id="menu-item-389" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-389"><a href="sponsers.php" target="_self">Sponsors</a></li>
						<li id="menu-item-380" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-380"><a href="gallery.php" target="_self">Gallery</a></li>
					</ul>
				</div>
			</nav>
		</div>
	</header>
<!-- ******************************** MAIN CONTAINER START ******************************** -->
 	<div id="container" class="container">
<!-- ******************************** SITE MAIN START ********************************-->
		<div id="main" class="site-main">
<!-- ******************************** SCROLLBAR ******************************** -->
			<div id="scrollbar">
<!-- ******************************** PRIMARY ********************************-->
				<div id="primary" class="viewport" data-horizontal-scroll="on">
<!-- ******************************** CONTENT ********************************-->
					<div id="content" class="overview" role="main">
<!-- ******************************** BACKGROUND IMAGE / CANVAS  START ********************************-->
						<div id="page-thumbnail" class="cover-image hscol large page">
							<div class="demo-1">
								<div class="content">
									<div id="large-header" class="large-header">
										<canvas id="demo-canvas"></canvas>
										<h1 class="main-title" style="color: #ffffff;font-family: 'Yanone Kaffeesatz', sans-serif;font-size: 500%; font-weight: 800%; text-shadow: 2px 2px 4px rgba(0,0,0,0.4); "><b>Aurora `15</b></span></h1><br><h5 class="main-title" style="font-size: 150%; font-weight: 800%;"><br><br><br><br><b>20th - 22nd, Feb 2015</b></h5>
									</div>
								</div>
							</div>
<!--<img width="960" height="534" src="images/main_background.png" class="attachment-large wp-post-image" alt="AURORA`15"/>-->
						</div>
<!-- ******************************** BACKGROUND IMAGE / CANVAS END ******************************** -->
<!-- ******************************** ABOUT AURORA START ******************************** -->
<!-- ******************************** EMPTY SEPARATOR START ********************************-->
						<div class="hscol vertical-title-container" style="background-color: #00151C; color: #93824E; ">
						</div>
						<div class="hscol page regular" style="width: 520px; background:url('images/diagmonds.png') repeat;color: #ffffff; "><!--<h2 style="text-align: center; font-family: 'Droid Sans', sans-serif; font-weight: 1000; font-size: 350%;"><span style="color: #93824e;">AURORA`15</span></h2><br>--></div>
						<div class="hscol page regular" style="width: 280px; background:url('images/diagmonds.png') repeat;color: #ffffff; "> 
							<br>
							<img src="images/iiitmlogo.png" width="150px" height="50px" /><br><br>
														<center><h3>20th - 22nd, Feb 2015</h3></center><br>

							<img src="images/logo.png"/>
						</div>

<!-- ******************************** EMPTY SEPARATOR END ********************************-->
						<div class="hscol vertical-title-container" style="background-color: #00151C; color: #93824E; ">
							<div class="blinking-arrow"></div>
							<div class="arrow-right" style="border-left-color: #00151C;"></div>
							<div class="arrow-bottom" style="border-top-color: #00151C;"></div>
							<h2 class="vertical-title">About</h2>
						</div>
						<div class="hscol page regular" style="width: 520px; background:url('images/diagmonds.png') repeat;color: #ffffff; ">
							<article id="post-189" class="post-189 page type-page status-publish has-post-thumbnail hentry">
							<div class="entry-content">
								<p>&nbsp;</p>
								<h2 style="text-align: center; font-family: 'Droid Sans', sans-serif; font-weight: 1000; font-size: 350%;"><span style="color: #93824e;">AURORA`15</span></h2><br>
								<h4 style="text-align: center;">AURORA`15 is ready to bewitch the hearts of the masses with an idiosyncratic blend of shimmer, mystique, stupendous talent, breathtaking performances, enrapturing panache, unnerving bands, aesthetic dance moves, soulful voices, top-notch art &amp; sublime actors from 20th-22nd, Feb-2015.</h4>
							</div> 
							</article> 
						</div>
						<!--
						<div class="cover-image hscol large page">
							<img width="689" height="1024" src="http://dark.acid.themevillage.net/wp-content/uploads/2013/04/bw.jpg" class="attachment-large wp-post-image" alt="b&amp;w"/>
						</div>
						-->
<!-- ******************************** ABOUT AURORA - END ********************************-->
<!-- ******************************** HIGHLIGHTS START ******************************** -->
						<div class="hscol vertical-title-container" style="background-color: #00151C; color: #93824E; ">
							<div class="arrow-right" style="border-left-color: #00151C;"></div>
							<div class="arrow-bottom" style="border-top-color: #00151C;"></div>
							<h2 class="vertical-title"> HIGHLIGHTS </h2>
						</div>
						<div class="hscol page regular" style="width: 950px; background:#1C985C url('images/diagmonds.png') repeat;color: #ffffff; ">
							<article id="post-443" class="post-443 page type-page status-publish has-post-thumbnail hentry">
							<div class="entry-content">
								<div class="grid-wrapper">
									<!--
									<div class="g one-third palm-one-whole ">
										<h4 style="text-align: center;"></h4>
										<h4 style="text-align: center;"><img class="alignnone size-full wp-image-384" src="http://bright.acid.themevillage.net/wp-content/uploads/2013/04/author11.png" alt="author1" width="205" height="230"/></h4>
										<h2 style="text-align: center; font-family: 'Droid Sans', sans-serif; font-weight: 1000; font-size: 350%; color:#93824e;">Pronites</h2>
										<h4 style="text-align: center;">The Celebrity Night</h4>
										<p>&nbsp;</p><p style="text-align: center; font-family: 'Merienda', cursive; font-weight: 250;"><a href="#" target="_self"class="pure-button small" >Coming Soon</a></p>
									</div>
									-->
									<div class="g one-half palm-one-whole ">
										<h4 style="text-align: center;"><img class="alignnone size-full wp-image-385" src="images/hexagons/corna.png" alt="author2" width="205" height="230"/></h4>
										<h4 style="text-align: center;"></h4>
										<h2 style="text-align: center; font-family: 'Droid Sans', sans-serif; font-weight: 1000; font-size: 350%; color:#93824e;">Corna</h2>
										<h4 style="text-align: center;">The Rock Band Competition</h4>
										<p>&nbsp;</p><p style="text-align: center; font-family: 'Merienda', cursive; font-weight: 250;"><a href="redirection/corna.php" target="_self"class="button small" >GET INFO</a></p>
									</div>
									<div class="g one-half palm-one-whole ">
										<h4 style="text-align: center;"><img class="alignnone size-full wp-image-386" src="images/hexagons/parivesh.png" alt="author3" width="205" height="230"/></h4>
										<h4 style="text-align: center;"></h4>
										<h2 style="text-align: center; font-family: 'Droid Sans', sans-serif; font-weight: 1000; font-size: 350%; color:#93824e;">Parivesh</h2>
										<h4 style="text-align: center;">The Fashion Extravaganza</h4>
										<p>&nbsp;</p><p style="text-align: center; font-family: 'Merienda', cursive; font-weight: 250;"><a href="redirection/parivesh.php" target="_self"class="button small" >GET INFO</a></p>
										<!--<div id="tipsy-social-icons-2" class="widget tipsy-social-icons">
											<div class="tipsy-social-icon-container">
												<ul class="tipsy-social-icons ">
													<li><a href="http://dribbble.com/Tanita " class="pure-icon icon-dribbble small-box"><span class="icon">Dribbble</span></a></li>
													<li><a href="https://www.facebook.com/puremellow " class="pure-icon icon-facebook small-box"><span class="icon">Facebook</span></a></li>
													<li><a href="# " class="pure-icon icon-github small-box"><span class="icon">Github</span></a></li>
												</ul> 
 
											</div> 
										</div> -->
									</div>
								</div>
							</div> 
							</article> 
						</div>
<!-- ******************************** HIGHLIGHTS ******************************** -->
<!-- ******************************** ABOUT PARIVESH START ********************************-->
						<div class="hscol vertical-title-container" style="background-color: #00151C; color: #93824E; ">
							<div class="arrow-right" style="border-left-color: #00151C;"></div>
							<div class="arrow-bottom" style="border-top-color: #00151C;"></div>
							<h2 class="vertical-title"> Parivesh </h2>
						</div>
						<div class="hscol page regular" style="width: 500px; background-color: #00151C repeat;color: #ffffff; ">
							<article id="post-265" class="post-265 page type-page status-publish has-post-thumbnail hentry">
							<div class="entry-content">
								<p>&nbsp;</p> <h2 style="text-align: center; font-family: 'Droid Sans', sans-serif; font-weight: 1000; font-size: 350%; color: #93824e;">Parivesh</h2>
								<h5 style="font-family: 'Merienda', cursive; font-weight: 250; text-align: center;">PARIVESH the fashion exhibit of AURORA`15 where fashion is inspired by youth and nostalgia and draws inspiration from the best of the past portraying the 20’s extravaganza. This is your once in a lifetime opportunity to live your childhood dream and be the next Miss. India! Grab the opportunity to become the next Vanya Mishra or Parvathy Omnikuttan and ensnare everyone’s senses!.</h5>
								<p>&nbsp;</p><p style="text-align: center; font-family: 'Merienda', cursive; font-weight: 250;"><a href="redirection/parivesh.php" target="_self"class="button small" >GET INFO</a></p>
							</div><!-- .entry-content -->
							</article><!-- #post-## -->
						</div>
<!-- ******************************** ABOUT PARIVESH END ******************************** -->
<!-- ******************************** PARIVESH START ******************************** -->
						<div class="hscol vertical-title-container" style="background-color:#00151C; color: #93824E; ">
							<div class="arrow-right" style="border-left-color:#00151C;"></div>
							<div class="arrow-bottom" style="border-top-color:#00151C;"></div>
							<h2 class="vertical-title" style="font-family: 'Merienda', cursive; font-weight: 100; font-size: 175%;"><center><b>The Fashion Extravaganza</b></center></h2>
						</div>
						<div class="hscol box-column">
							
							<div class="box" data-follower-color="#93824E" style="background-color: #93824E;">
								<a class="box__link  js--link  colorbox" rel="protfolio" href="images/parivesh/large/3.jpg" title="Sunny Life">
								<img width="600" height="600" src="images/parivesh/3.jpg" class="attachment-pure_thumbnail wp-post-image" alt="sunny life"/>
							<div class="box__content "><h2 class="entry-title">Sunny Life</h2></div>
								</a>
							</div>
								<div class="box" data-follower-color="#93824E" style="background-color: #93824E;">
								<a class="box__link  js--link  colorbox" rel="protfolio" href="images/parivesh/large/5.jpg" title="Raven">
								<img width="600" height="600" src="images/parivesh/5.jpg" class="attachment-pure_thumbnail wp-post-image" alt="raven"/>
								<div class="box__content "><h2 class="entry-title">Raven</h2></div>
								</a>
							</div>
						</div>
						
						<div class="hscol box-column">
							<div class="box" data-follower-color="#93824E" style="background-color: #93824E;">
								<a class="box__link  js--link  colorbox" rel="protfolio" href="images/parivesh/large/6.jpg" title="Church">
								<img width="600" height="600" src="images/parivesh/6.jpg" class="attachment-pure_thumbnail wp-post-image" alt="church"/>
								<div class="box__content "><h2 class="entry-title">Church</h2></div>
								</a>
							</div>
							<div class="box" data-follower-color="#93824E" style="background-color: #93824E;">
								<a class="box__link  js--link  colorbox" rel="protfolio" href="images/parivesh/large/7.jpg" title="Curious">
								<img width="600" height="600" src="images/parivesh/7.jpg" class="attachment-pure_thumbnail wp-post-image" alt="girl"/>
								<div class="box__content "><h2 class="entry-title">Curious</h2></div>
								</a>
							</div>
							
						</div>
					
<!-- ******************************** PARIVESH END ******************************** -->
<!-- ******************************** ABOUT CORNA ******************************** -->
						<div class="hscol page regular" style="width: 500px; background:url('images/diagmonds.png') repeat;color: #ffffff; ">
							<article id="post-265" class="post-265 page type-page status-publish has-post-thumbnail hentry">
							<div class="entry-content">
								<p>&nbsp;</p><h2 style="text-align: center; font-family: 'Droid Sans', sans-serif; font-weight: 1000; font-size: 350%; color: #93824e;">CORNA</h2>
								<h4 style="text-align: center;">Gear up to feel the enchanting and unnerving fresh music coming straight from the guitar and tap to the beats of drums, enthral yourself with the mesmerizing voice of the talented bunch of singers. Recreating the 20’s extravaganza, Corna is all set to rock with the budding Linkin Park and Green Day!</h4>
								<p>&nbsp;</p><p style="text-align: center;"><a href="redirection/corna.php" target="_self"class="button small" >GET INFO</a></p>
							</div><!-- .entry-content -->
							</article><!-- #post-## -->
						</div>
<!-- ******************************** ABOUT CORNA END ******************************** -->
<!-- ******************************** CORNA START ******************************** -->
						<div class="hscol vertical-title-container" style="background-color: #00151C; color: #93824E; ">
							<div class="arrow-right" style="border-left-color: #00151C;"></div>
							<div class="arrow-bottom" style="border-top-color: #00151C;"></div>
							<h2 class="vertical-title" style="font-family: 'Merienda', cursive; font-weight: 100; font-size: 175%;"><b>The Rock Band Competitions</b> </h2>
						</div>
						
						<div class="hscol box-column">
							<div class="box" data-follower-color="#989d80" style="background-color: #989d80;">
								<a class="box__link  js--link  colorbox" rel="protfolio" href="images/corna/large/2.jpg" title="Smokestack Menu">
								<img width="600" height="600" src="images/corna/2.jpg" class="attachment-pure_thumbnail wp-post-image" alt="Smokestack-menu"/>
								<div class="box__content "><h2 class="entry-title">Rocking through your nerves</h2></div>
								</a>
							</div>
							<div class="box" data-follower-color="#707D46" style="background-color: #707D46;">
								<a class="box__link  js--link  colorbox" rel="protfolio" href="images/corna/large/1.jpg" title="Oh Gee">
								<img width="600" height="600" src="images/corna/1.jpg" class="attachment-pure_thumbnail wp-post-image" alt="oh gee"/>
								<div class="box__content "><h2 class="entry-title">Rock Band Competition</h2></div>
								</a>
							</div>
							
						</div>
						<div class="hscol box-column">
							<div class="box" data-follower-color="#CA4302" style="background-color: #CA4302;">
								<a class="box__link  js--link  colorbox" rel="protfolio" href="images/corna/large/5.jpg" title="Vegas">
								<img width="600" height="600" src="images/corna/5.jpg" class="attachment-pure_thumbnail wp-post-image" alt="vegas"/>
								<div class="box__content "><h2 class="entry-title">Corna</h2></div>
								</a>
							</div>

							<div class="box" data-follower-color="#30A3B8" style="background-color: #30A3B8;">
								<a class="box__link  js--link  colorbox" rel="protfolio" href="images/corna/large/3.jpg" title="Maiden in Distress">
								<img width="560" height="600" src="images/corna/3.jpg" class="attachment-pure_thumbnail wp-post-image" alt="future"/>
								<div class="box__content "><h2 class="entry-title">Strumming through the Beats</h2></div>
								</a>
							</div>
						</div>
					
<!-- ******************************** CORNA END ********************************-->
<!-- ******************************** NEED INSTRUCTIONS ******************************** -->
						<div class="hscol page regular" style="width: 500px; background:url('images/diagmonds.png') repeat;color: #93824E; ">
							<article id="post-299" class="post-299 page type-page status-publish has-post-thumbnail hentry">
							<div class="entry-content">
								<p>&nbsp;</p><h2 style="text-align: center; font-family: 'Droid Sans', sans-serif; font-weight: 1000; font-size: 350%">EVENTS</h2>
								<p></p><h4 style="color: #ffffff">Aurora dovetails all the different colors and flavors of India together in one place and makes the colors come alive with its jinx, casting a spell on the audience. Aurora`15 comes with tons of newborn events and lot more whoopee and pep.  </h4><br>
								<p style="text-align: center;">Click on the icon below to see about all the events</p>
								<p style="text-align: center;"><a href="events.php" target="_blank"><span class="batch iconfont-nuts">&#xF0DD;</span></a></p>
							</div> 
							</article> 
						</div>
<!-- ******************************** NEED INSTRUCTIONS ********************************-->
<!-- ******************************** RECENT POSTS ********************************-->
						<div class="hscol vertical-title-container" style="background-color: #00151C; color: #93824E; ">
							<div class="arrow-right" style="border-left-color: #00151C;"></div>
							<div class="arrow-bottom" style="border-top-color: #00151C;"></div>
							<h2 class="vertical-title"> Check Them </h2>
						</div>
						<div class="hscol box-column">
							<div class="box" data-follower-color="#91c77a" style="background-color: #91c77a;">
    							<a class="box__link js--link" href="redirection/dance_carnival.php" title="Dance Carnival">       
    							<img width="600" height="600" src="images/dance_carnival.jpg" class="attachment-pure_thumbnail wp-post-image" alt="Dance Carnival" />			
       							<div class="box__content visible">
        							
        	 						<div class="box__content"><h2 class="entry-title">Dance Carnival</h2></div>
        						</div>
								</a>
							</div>
								<div class="box" data-follower-color="#7a0049" style="background-color: #7a0049;">
    							<a class="box__link js--link" href="redirection/phoenix.php" title="The Best Oldies"> 
    							<img width="600" height="600" src="images/phoenix.jpg" class="attachment-pure_thumbnail wp-post-image" alt="Phoenix" />
        						<div class="box__content visible">
						        	
        	 						<div class="box__content"><h2 class="entry-title">Phoenix</h2></div>
        						</div>
								</a>
							</div>
						</div>
						<div class="hscol box-column">
							<div class="box" data-follower-color="#8a0000" style="background-color: #8a0000;">
    							<a class="box__link js--link" href="redirection/aurora_idol.php" title="Aurora Idol"> 
    							<img width="600" height="600" src="images/aurora_idol.jpg" class="attachment-pure_thumbnail wp-post-image" alt="Aurora Idol" />			
    							<div class="box__content visible">
        							
        	 						<div class="box__content"><h2 class="entry-title">Aurora Idol</h2></div>
        	 					</div>
        	 					</a>
							</div>
							<div class="box" data-follower-color="#8a0000" style="background-color: #8a0000;">
							    <a class="box__link js--link" href="redirection/treasure_hunt.php" title="Treasure Hunt">  <img width="600" height="600" src="images/treasure_hunt.jpg" class="attachment-pure_thumbnail wp-post-image" alt="Treasure Hunt" /> 
 
							    <div class="box__content visible">
							    
							    	<div class="box__content"><h2 class="entry-title">Treasure Hunt</h2></div>
        						</div>
        						</a>
							</div>
						</div>
						<div class="hscol box-column">
							<div class="box" data-follower-color="#d4a308" style="background-color: #d4a308;">
    							<a class="box__link js--link" href="redirection/mnm.php" title="Mr. n Ms. Aurora">       
								<img width="600" height="600" src="images/mnm.jpg" class="attachment-pure_thumbnail wp-post-image" alt="Art Mela" />	
        						<div class="box__content visible">
        							
        	 						<div class="box__content"><h2 class="entry-title">Mr. n Ms. Aurora</h2></div>
								</div>
								</a>
							</div>
							<div class="box" data-follower-color="#c2a568" style="background-color: #c2a568;">
							    <a class="box__link js--link" href="redirection/lol.php" title="Laugh Out Loud">       
								<img width="600" height="600" src="images/lol.jpg" class="attachment-pure_thumbnail wp-post-image" alt="Laugh Out Loud" />		
						       <div class="box__content visible">
						        	
        	 						<div class="box__content"><h2 class="entry-title">Laugh Out Loud</h2></div>
								</div>
								</a>
							</div>
						</div>
						<div class="hscol box-column">
						<div class="box" data-follower-color="#DE5500" style="background-color: #DE5500;">
    							<a class="box__link js--link" href="redirection/art_mela.php" title="ART Mela">       
    							<img width="600" height="600" src="images/art_mela.jpg" class="attachment-pure_thumbnail wp-post-image" alt="Art Mela" />			
        						<div class="box__content visible">
        							
        	 						<div class="box__content"><h2 class="entry-title">Art Mela</h2></div>
        						</div>
								</a>
							</div>
							<div class="box" data-follower-color="#d4a308" style="background-color: #d4a308;">
    							<a class="box__link js--link" href="redirection/streetplay.php" title="Street Play">    
 <img width="600" height="600" src="images/streetplay.jpg" class="attachment-pure_thumbnail wp-post-image" alt="Street Play" /> 
        						<div class="box__content visible">
						        	
        	 						<div class="box__content"><h2 class="entry-title">Street Play</h2></div>
        						</div>
								</a>
							</div>
						</div>
			
<!--********************************  RECENT POSTS END ********************************-->
<!-- ******************************** SERVICES START ********************************-->
<!--
						<div class="hscol vertical-title-container" style="background-color: #00151C; color: #93824E; ">
							<div class="arrow-right" style="border-left-color: #00151C;"></div>
							<div class="arrow-bottom" style="border-top-color: #00151C;"></div>
							<h2 class="vertical-title"> INFORMALS </h2>
						</div>
						<div class="hscol page regular" style="width: 800px; background:url('images/diagmonds.png') repeat;color: #ffffff; ">
							<article id="post-286" class="post-286 page type-page status-publish has-post-thumbnail hentry">
							<div class="entry-content">
								<div class="grid-wrapper">
									<div class="g one-half ">
										<p>&nbsp;</p><p style="text-align: center;"><span style="color: #93824e;"><span class="batch iconfont-xxl">&#xF078;</span></span></p>
										<h3 style="text-align: center; font-family: 'Droid Sans', sans-serif; font-weight: 1000; font-size: 140%;"><span style="color: #93824e;">Event Photography</span></h3>
										<p style="text-align: center;">Having no desire to awaken their nasty tempers upon such a night as this, where so much depended upon secrecy and dispatch.</p>
										<p>&nbsp;</p><p style="text-align: center;"><span style="color: #93824e;"><span class="batch iconfont-xxl">&#xF047;</span></span></p>
										<h3 style="text-align: center; font-family: 'Droid Sans', sans-serif; font-weight: 1000; font-size: 140%;"><span style="color: #93824e;">Everyone Likes Me</span></h3>
										<p style="text-align: center;">How I thanked the kind providence had given me the foresight to win the love and confidence of these wild dumb brutes.</p>
									</div>
									<div class="g one-half ">
										<p>&nbsp;</p><p style="text-align: center;"><span style="color: #93824e;"><span class="batch iconfont-xxl">&#xF07B;</span></span></p>
										<h3 style="text-align: center; font-family: 'Droid Sans', sans-serif; font-weight: 1000; font-size: 140%;"><span style="color: #93824e;">Location Photography</span></h3>
										<p style="text-align: center;">How I thanked the kind providence had given me the foresight to win the love and confidence of these wild dumb brutes.</p>
										<p>&nbsp;</p><p style="text-align: center;"><span style="color: #93824e;"><span class="batch iconfont-xxl">&#xF12B;</span></span></p>
										<h3 style="text-align: center; font-family: 'Droid Sans', sans-serif; font-weight: 1000; font-size: 140%;"><span style="color: #93824e;">Photo Editing</span></h3>
										<p style="text-align: center;">How I thanked the kind providence had given me the foresight to win the love and confidence of these wild dumb brutes.</p>
									</div>
								</div>
							</div> 
							</article> 
						</div>
						<div class="hscol page regular" style="width: 800px; background:url('images/diagmonds.png') repeat;color: #ffffff; ">
							<article id="post-286" class="post-286 page type-page status-publish has-post-thumbnail hentry">
							<div class="entry-content">
								<div class="grid-wrapper">
									<div class="g one-half ">
										<p>&nbsp;</p><p style="text-align: center;"><span style="color: #93824e;"><span class="batch iconfont-xxl">&#xF078;</span></span></p>
										<h3 style="text-align: center; font-family: 'Droid Sans', sans-serif; font-weight: 1000; font-size: 140%;"><span style="color: #93824e;">Event Photography</span></h3>
										<p style="text-align: center;">Having no desire to awaken their nasty tempers upon such a night as this, where so much depended upon secrecy and dispatch.</p>
										<p>&nbsp;</p><p style="text-align: center;"><span style="color: #93824e;"><span class="batch iconfont-xxl">&#xF047;</span></span></p>
										<h3 style="text-align: center; font-family: 'Droid Sans', sans-serif; font-weight: 1000; font-size: 140%;"><span style="color: #93824e;">Everyone Likes Me</span></h3>
										<p style="text-align: center;">How I thanked the kind providence had given me the foresight to win the love and confidence of these wild dumb brutes.</p>
									</div>
									<div class="g one-half ">
										<p>&nbsp;</p><p style="text-align: center;"><span style="color: #93824e;"><span class="batch iconfont-xxl">&#xF07B;</span></span></p>
										<h3 style="text-align: center; font-family: 'Droid Sans', sans-serif; font-weight: 1000; font-size: 140%;"><span style="color: #93824e;">Location Photography</span></h3>
										<p style="text-align: center;">How I thanked the kind providence had given me the foresight to win the love and confidence of these wild dumb brutes.</p>
										<p>&nbsp;</p><p style="text-align: center;"><span style="color: #93824e;"><span class="batch iconfont-xxl">&#xF12B;</span></span></p>
										<h3 style="text-align: center; font-family: 'Droid Sans', sans-serif; font-weight: 1000; font-size: 140%;"><span style="color: #93824e;">Photo Editing</span></h3>
										<p style="text-align: center;">How I thanked the kind providence had given me the foresight to win the love and confidence of these wild dumb brutes.</p>
									</div>
								</div>
							</div> 
							</article> 
						</div>
						-->
<!-- ******************************** SERVICES END ********************************-->
<!-- ******************************** SEPARATOR START ********************************-->
						<div class="hscol vertical-title-container" style="background-color: #00151C; color: #93824E; ">
							<div class="arrow-right" style="border-left-color: #00151C;"></div>
							<div class="arrow-bottom" style="border-top-color: #00151C;"></div>
							<h2 class="vertical-title">Technical</h2>
						</div>
						<div class="hscol page default" style="width: 600px; background:url('images/diagmonds.pngg') repeat;color: #ffffff; ">
							<article id="post-305" class="post-305 page type-page status-publish has-post-thumbnail hentry">
							<div class="entry-content">
								<p>&nbsp;</p><h2 style="text-align: center;"><span style="color: #93824e;">THE ONE APP</span></h2>
								<h4><span style="color: #93824e;">&nbsp;&nbsp;&nbsp;SPARK THE NEURONS .... </span></h4><br>
								<h3>“Nothing worthwhile is ever achieved without complications.”</h3>
								<h4 style="text-align: center;">The One App beckons to all the binary gurus who can come up with avant-garde methods to revolutionize the very definition of innovation. Revise your coding languages for this contest is prepared to challenge everything you know, everything you are!</h4>
								<p>&nbsp;</p><p style="text-align: center;"><a href="#" class="button medium" >Coming Soon</a></p>
							</div><!-- .entry-content -->
							</article><!-- #post-## -->
						</div>
						<div class="hscol page default" style="width: 600px; background:url('images/diagmonds.pngg') repeat;color: #ffffff; ">
							<article id="post-305" class="post-305 page type-page status-publish has-post-thumbnail hentry">
							<div class="entry-content">
								<p>&nbsp;</p><h2 style="text-align: center;"><span style="color: #93824e;">CODING 
								</span></h2>
								<h4><span style="color: #93824e;">&nbsp;&nbsp;&nbsp;TAME THE CODE ... </span></h4><br>
								<h3>“In theory, theory and practice are the same. In practice, they’re not.”</h3>
								<h4 style="text-align: center;">Do you idolize Zuckerberg and Rossum?? Think you have what it takes to develop a code?  Aurora 2k15 brings to you an opportunity to unleash your coding skills and outsmart your participants. Sit on your monitors and feel the rush of adrenaline during this extravaganza!</h4>
								<p>&nbsp;</p><p style="text-align: center;"><a href="#" class="button medium" >Coming Soon</a></p>
							</div><!-- .entry-content -->
							</article><!-- #post-## -->
						</div>
						<div class="hscol page default" style="width: 600px; background:url('images/diagmonds.pngg') repeat;color: #ffffff; ">
							<article id="post-305" class="post-305 page type-page status-publish has-post-thumbnail hentry">
							<div class="entry-content">
								<p>&nbsp;</p><h2 style="text-align: center;"><span style="color: #93824e;">The Smart Idea</span></h2>
								<h4><span style="color: #93824e;">&nbsp;&nbsp;&nbsp; RECONSTRUCTING CHANGE ... </span></h4><br>
								<h3>“Life is a crisis – So What! Well, if it can be thought, it can be done, a problem can be overcome”</h3>
								<h4 style="text-align: center;">If tricky problem statements intrigue you and planning and management is your forte, then Smart Idea is yet another challenge to let the mastermind in you come up with an efficacious design, a resource utilization plan.</h4>
								<p>&nbsp;</p><p style="text-align: center;"><a href="#" class="button medium" >Coming Soon</a></p>
							</div><!-- .entry-content -->
							</article><!-- #post-## -->
						</div>

<!-- ******************************** SEPARATOR END ********************************-->
<!-- ******************************** VIDEO START ******************************** -->
						<!--
						<div class="hscol vertical-title-container" style="background-color: #00151C; color: #93824E; ">
							<div class="arrow-right" style="border-left-color: #00151C;"></div>
							<div class="arrow-bottom" style="border-top-color: #00151C;"></div>
							<h2 class="vertical-title">Technical</h2>
						</div>
						<div class="hscol page regular" style="width: 1050px; background:#3E5F96 url('images/diagmonds.png') repeat;">
							<article id="post-222" class="post-222 page type-page status-publish has-post-thumbnail hentry">
							<div class="entry-content">
								<p>&nbsp;</p><p></p>
							</div>
							</article>
						</div>
						-->
<!-- ******************************** VIDEO END ******************************** -->
<!-- ******************************** VIDEO GUIDE ******************************** -->
						<div class="hscol vertical-title-container" style="background-color: #00151C; color: #93824E; ">
							<div class="arrow-right" style="border-left-color: #00151C;"></div>
							<div class="arrow-bottom" style="border-top-color: #00151C;"></div>
							<h2  class="vertical-title" > Video </h2>
						</div>
						<div class="hscol page regular" style="width: 500px; background:#3E5F96 url('images/diagmonds.png') repeat;color: #ffffff; ">
							<article id="post-449" class="post-449 page type-page status-publish has-post-thumbnail hentry">
							<div class="entry-content"><br><br><br>
								<iframe width="560" height="315" src="//www.youtube.com/embed/4m3t6By-SYg" frameborder="0" allowfullscreen></iframe><br><br>
								<p style="text-align: center; color: #93824e;">Click on the icon below to see about all the events</p>
								<p></p><p style="text-align: center;"><a href="https://www.youtube.com/user/auroraabviiitm" target="_blank"><span class="batch iconfont-nuts">&#xF042;</span></a></p>
							</div> 
							</article> 
						</div>
<!-- ******************************** VIDEO GUIDE END ******************************** -->
<!-- ******************************** CONTACT US ********************************-->
<!--
						<div class="hscol vertical-title-container" style="background-color: #00151C; color: #93824E; ">
							<div class="arrow-right" style="border-left-color: #00151C;"></div>
							<div class="arrow-bottom" style="border-top-color: #00151C;"></div>
							<h2 class="vertical-title"  > Contact Us </h2>
						</div>
						<div class="hscol page regular" style="width: 800px; background:url('images/diagmonds.pngg') repeat;color: #ffffff; ">
							<article id="post-450" class="post-450 page type-page status-publish hentry">
							<div class="entry-content">
								
										<p>&nbsp;</p><h2 style="color: #93824E; text-align: center; font-family: 'Droid Sans', sans-serif; font-weight: 1000; font-size: 350%">Contact info</h2>
										<h2 style="font-family: 'Merienda', cursive; font-weight: 400; font-size: 160%; color:#93824e;"><strong>Address :</strong></h2><h5> ABV-Indian Institute of Information Technology & Management,<br> Morena Link Road, Gwalior <br>Madhya Pradesh, INDIA - 474015.</h5><br/>
										<h2 style="font-family: 'Merienda', cursive; font-weight: 400; font-size: 160%; color:#93824e;"><strong>Email :</strong></h2><h5> contact@aurora15.org</h5><br/>
										<h2 style="font-family: 'Merienda', cursive; font-weight: 400; font-size: 160%; color:#93824e;"><strong>Telephone :</strong></h2><h5>+91 9406577543</h5>
										<div id="tipsy-social-icons-2" class="widget tipsy-social-icons">
											<div class="tipsy-social-icon-container">
												<ul class="tipsy-social-icons ">
													<li><a href="https://www.youtube.com/user/auroraabviiitm " class="pure-icon icon-youtube small-box"><span class="icon">You Tube</span></a></li>
													<li><a href="https://www.facebook.com/Aurora.IIITM" class="pure-icon icon-facebook small-box"><span class="icon">Facebook</span></a></li>
												</ul> 
 											</div> 
										</div>-->
									<!--
									<div class="g one-half "><br><br>
										<form id="cntctfrm_contact_form" action="mailto:aakashkh284@gmail.com" method="post">
										<div style="text-align: left; padding-top: 5px;">
											<label for="cntctfrm_contact_name" style="font-family: 'Merienda', cursive; font-weight: 400; font-size: 160%; color:#93824e;">Name: <span class="required">*</span></label>
										</div>
										<div style="text-align: left;">
											<input class="text" type="text" size="40" value="" name="cntctfrm_contact_name" id="cntctfrm_contact_name" style="text-align: left; margin: 0;"/>
										</div>
										<div style="text-align: left;">
											<label for="cntctfrm_contact_email" style="font-family: 'Merienda', cursive; font-weight: 400; font-size: 160%; color:#93824e;">Email Address: <span class="required">*</span></label>
										</div>
										<div style="text-align: left;">
											<input class="text" type="text" size="40" value="" name="cntctfrm_contact_email" id="cntctfrm_contact_email" style="text-align: left; margin: 0;"/>
										</div>
										<div style="text-align: left;">
											<label for="cntctfrm_contact_message" style="font-family: 'Merienda', cursive; font-weight: 400; font-size: 160%; color:#93824e;">Message: <span class="required">*</span></label>
										</div>
										<div style="text-align: left;">
											<textarea rows="5" cols="30" name="cntctfrm_contact_message" id="cntctfrm_contact_message"></textarea>
										</div>
										<div style="text-align: left; padding-top: 8px;">
											<input type="hidden" value="send" name="cntctfrm_contact_action"><input type="hidden" value="Version: 3.30"/>
											<input type="hidden" value="en" name="cntctfrm_language">
											<input type="submit" value="Submit" style="cursor: pointer; margin: 0pt; text-align: center;margin-bottom:10px;"/>
										</div>
										</form>
									</div> -->
								<!--
							</div>
							</article> 
						</div>		
-->
<!-- ******************************** CONTACT US END ********************************-->
<!-- ******************************** CONTENT ******************************** -->
					</div> 
<!-- ******************************** PRIMARY ********************************-->
				</div>  
<!-- ******************************** FOOTER STARTS ********************************-->
				<footer id="footer" class="site-footer" role="contentinfo">
					<div id="footer-arrow"><span>+</span></div>
					<div id="footer-content" class="site-info">
						<div class="grid-wrapper">
							<aside id="text-2" class="widget widget_text"><h1 class="widget-title" style="color: #93824e; font-family: 'Droid Sans', sans-serif; font-weight: 1000; font-size: 300%;">Web Credits</h1>
							<div class="textwidget" style="font-family: 'Droid Sans', sans-serif; font-weight: 1000; font-size: 200%;">Aakash Khandelwal</div>
								
								<ul class="tipsy-social-icons ">					
									<li><a href="# " class="pure-icon icon-linkedin small-box"><span class="icon"> &nbsp;&nbsp;LinkedIn</span></a></li>	
									<li><a href="# " class="pure-icon icon-github small-box"><span class="icon"> &nbsp;&nbsp; Github</span></a></li>					
									<li><a href="# " class="pure-icon icon-facebook small-box"><span class="icon">Facebook</span></a>
									</li>
								</ul>
							</aside>
							<aside id="tipsy-social-icons-3" class="widget tipsy-social-icons">
							<h1 style="color: #93824e; font-family: 'Droid Sans', sans-serif; font-weight: 1000; font-size: 300%;">&nbsp; &nbsp;&nbsp;&nbsp; &nbsp;&nbsp;Like and Share us on - </h1><br>
								
									<div style="margin-left:30%;">	
									<a href="https://www.youtube.com/user/auroraabviiitm" class="pure-icon icon-youtube small-box"><span class="icon">You Tube</span></a>
														
									<a href="https://www.facebook.com/Aurora.IIITM" class="pure-icon icon-facebook small-box"><span class="icon">Facebook</span></a>


									<br><br><br><br>
 <audio controls autoplay 2>
 
  <source src="tone.mp3" type="audio/mpeg">
  Your browser does not support the audio element.
</audio> 
									
									</div>
									
								
								<br><br><br><br><br>
								<h3> &copy; AURORA`15  - <em>Ensnaring Thy Senses</em>...</h3>
							</aside>
							<aside id="tag_cloud-3" class="widget widget_tag_cloud">
							<h1 class="widget-title" style="color: #93824e; font-family: 'Droid Sans', sans-serif; font-weight: 1000; font-size: 300%;">Contact US</h1>
								<h4 style="font-family: 'Droid Sans', sans-serif; font-size: 120%;"><b>Address :  </b> ABV-Indian Institute of Information Technology & Management,<br> Morena Link Road, Gwalior <br>Madhya Pradesh, INDIA - 474015.</h4><br>
								<h4 style="font-family: 'Droid Sans', sans-serif; font-size: 120%;"><b>Email :  </b> contact@aurora15.in</h4>
							</aside>
						</div>
					</div>
				</footer>
<!--******************************** FOOTER END ******************************** -->
				<div class="scrollbar"><div class="track"><div class="thumb"></div></div></div>
<!-- ******************************** SCROLLBAR ********************************-->
			</div>  
<!-- ******************************** SITE MAIN END ******************************** -->
		</div> 
<!-- ******************************** MAIN CONTAINER START ********************************-->
	</div> 
<!-- ******************************** MAIN DIV START ******************************** -->
</div> 
<!-- ******************************** Scripts******************************** -->
<script type='text/javascript' src='js/libs.js'></script>
<script type='text/javascript' src='js/app.js'></script>
<script type='text/javascript' src='js/comment-reply.min.js'></script>
<script src="js/TweenLite.min.js"></script>
<script src="js/EasePack.min.js"></script>
<script src="js/rAF.js"></script>
<script src="js/demo-1.js"></script>
<!-- ******************************** BODY END ********************************-->
</body>
</html>
 