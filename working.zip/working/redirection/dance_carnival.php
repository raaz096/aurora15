<?php include 'rest-header.php';?>
		<title>Dance Carival | Events | Aurora`15</title>
		<style type="text/css">
  p{ 	
        font-size: 90%;
        margin: 5%;
        font-weight: 700;
        text-align:left;
        
  }
</style>
		<div class="md-modal md-effect-1" id="modal-1">
      <div class="md-content">
        <h1 style="font-size: 190%; color: #93824a;">Nupur</h1>
        
          <p>Solo Dancing Competition: A stage to showcase an individual’s dancing skills. You get an opportunity to hype your dancing skills and emerge as the next DID champion! So grab the chance and set your mark with NUPUR!</p>
           <h1 style="font-size: 190%; color: #93824a;">Rules</h1>
           <p>
           Maximum time limit:<br>
<b>Elimination round:</b> 3 min.&nbsp;&nbsp;&nbsp;
<b>Final round: </b>5 min.<br>
1. Only the participants decided by the judge will qualify for the final round.<br>
2. It is not necessary for the participants to perform on different songs for elimination and final round.<br>
3. Costumes are not necessary for the elimination round but marks will be given for costumes and props in the final round.</p>
          <button class="md-close">Close me!</button>
        <br><br>
      </div>
    </div>
    <div class="md-modal md-effect-2" id="modal-2">
      <div class="md-content">
        <h1 style="font-size: 190%; color: #93824a;">DANCING JODI </h1>
        
          <p>Couple Dance Competition: It’s time to cha-cha, jive, salsa, tango, rumba, samba and waltz around the floor with your partner. Couple dance requires vehement chemistry and efficacious co-ordination. So you can also be the next Nach Baliye of India with Dancing Jodi!!!</p>
           <h1 style="font-size: 190%; color: #93824a;">Rules</h1>
           <p>
           Maximum time limit:<br>
<b>Elimination round:</b> 3 min.&nbsp;&nbsp;&nbsp;
<b>Final round: </b>5 min.<br>
1. Only the couples selected by the judge in the elimination round will qualify for the final round.<br>
2. It is not necessary for the participants to perform on different songs for elimination and final round.</p>
          <button class="md-close">Close me!</button>
        <br><br>
      </div>
    </div>
    <div class="md-modal md-effect-3" id="modal-3">
      <div class="md-content">
       <h1 style="font-size: 190%; color: #93824a;">Just Do It</h1>
        
          <p>Spontaneous Dancing: An unplanned but obviously pre-choreographed outburst of dancing within a normal, non-party setting. So if you think you are a born dancer then exhibit your flamboyance and artistry with JUST DO IT!</p>
             <h1 style="font-size: 190%; color: #93824a;">Rules</h1>
           <p>
           The song on which the participant has to perform will be given on the spot.<br>
           Maximum time limit:<br>
<b>Elimination round:</b> 90 sec.&nbsp;&nbsp;&nbsp;
<b>Final round: </b>3 min.<br>
1. For the elimination two participants will have to perform on the same song simultaneously.<br>
2. For the final round each participant will have to perform on a song which will be given on the spot.<br>
3. Only the participants who are selected by the judge will qualify for the final round.
</p>
          <button class="md-close">Close me!</button>
        <br><br>
      </div>
    </div>
    <div class="md-modal md-effect-1" id="modal-4">
      <div class="md-content">
        <h1 style="font-size: 190%; color: #93824a;">Syncro Funk</h1>
       
          <p>Group Dance Competition: Synchronization is what matters the most in a group performance and team spirit its essence. Syncro funk tests your team adroitness and provides you the platform to emerge as an idiosyncratic group like the ones in India has got talent.</p>
            <h1 style="font-size: 190%; color: #93824a;">Rules</h1>
           <p>
           Minimum number of team member-3<br>
Maximum number of team member-15<br>
           Maximum time limit:<br>
<b>Elimination round:</b> 4 min.&nbsp;&nbsp;&nbsp;
<b>Final round: </b>6 min.<br>
All the teams will first have to compete in the elimination round. Only the teams selected by the judge will qualify for the next round.</p>

          <button class="md-close">Close me!</button>
        <br><br>
      </div>
    </div>
    <div class="md-modal md-effect-2" id="modal-5">
      <div class="md-content">
        <h1 style="font-size: 190%; color: #93824a;">Sanskriti</h1>
                  <p>   Maximum time limit:<br>
Elimination round: 5 min.&nbsp;&nbsp;&nbsp;
Final round: 6 min.<br>
1. Participants are required to represent the folk or culture of their state through their dance.<br>
2. Only the participants who are selected by the judge will qualify for the final round.<br>
3. Points will be awarded on the basis of how deeply and beautifully the teams delve into their state’s dance cultures and styles.</p>
            <button class="md-close">Close me!</button>
        <br><br>
      </div>
    </div>
    <div class="md-modal md-effect-3" id="modal-6">
      <div class="md-content">
        <h2>HeadSpin</h2>
        <div>
          <p>Coming Soon ....</p>
            <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
    <div class="md-modal md-effect-1" id="modal-7">
      <div class="md-content">
         <h1 style="font-size: 190%; color: #93824a;">Rules</h1>
        
          <p>1. Props will have to be arranged by participants themselves.<br>
2. The dance floor area must be restored to its original state after use.<br>
3. Special light and sound facility (if any required) must be supervised by team member.<br>
4. Indecent outfits and any vulgarity in performance would lead to deduction in marks.<br>
5. Exceeding time limit will also lead to deduction of marks.<br>
6. Exceeding time limit by more than 1 min: -5 marks<br>
7. All the events will be held here at IIITM campus on the dates of fest.</p>
            <button class="md-close">Close me!</button>
        <br><br>
      </div>
    </div>
    <div class="md-modal md-effect-2" id="modal-8">
      <div class="md-content">
         <h1 style="font-size: 190%; color: #93824a;">Timeline</h1>
        <div>
          <p>Coming Soon ....</p>
            <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
    <div class="md-modal md-effect-3" id="modal-9">
      <div class="md-content">
         <h1 style="font-size: 190%; color: #93824a;">Contact</h1>
        
          <p>Sandeep Maurya  &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;     sandeepmaury96@gmail.com<br>
Akula Akhil          &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;            akhil2050039@gmail.com<br>
Gaurav Singh           &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;         	gauravsingh1195@gmail.com<br>
Lucky Suman            &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;        	luckysuman850@gmail.com<br>
Ritu Jha               &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;           ritujha1695@gmail.com<br>
Shreya Sahu             &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;   &nbsp;&nbsp; &nbsp;&nbsp;  		shreya.iiitm@gmail.com</p>
            <button class="md-close">Close me!</button>
        
      </div>
    </div>
   
		<div class="container">
			<header>
				<?php include 'rest-navigation.php';?>
				<h1>Dance Carnival <span><br>The entire world’s a stage.Bringing back the 20’s
extravaganza, the era wherein contests like Dance
India Dance and India’s dancing superstar created a
whiz bang and enkindled dancing sensations like Prince
and Dharmesh Sir. So are you willing to show your
masala on the stage? Or set the stage on fire with the
colors and mesmerize us with your latkas, jhatkas &amp;
thumkas. Bollywood ishtyle!</span></h1>
					<button class="md-trigger" data-modal="modal-1">Nupur</button>
					<button class="md-trigger" data-modal="modal-2">Dancing Jodi</button>
					<button class="md-trigger" data-modal="modal-3">Just Do It</button>
					<button class="md-trigger" data-modal="modal-4">Synchro Funk</button>
					<button class="md-trigger" data-modal="modal-5">Sanskriti</button>
					<button class="md-trigger" data-modal="modal-6">HeadSpin</button>
					
							</header>
			<div class="main clearfix">
				<div class="column">
				<section class="rw-wrapper">
						<h3 class="rw-sentence">
						<div class="rw-words rw-words-1" style="margin-left:20%;">
							<span>Dancing Jodi</span>
							<span>Nupur</span>
							<span>Synchro Funk </span>
							<span>Freaky Freestyle</span>
							<span>Just Do It </span>
							<span>Prop &amp; Dance</span>
						</div>
						</h3>
					</section>
					<br><br><br><br><br><br>
					<button class="md-trigger" data-modal="modal-7">Rules</button><br>
					<button class="md-trigger" data-modal="modal-8">Timeline</button><br>
					<button class="md-trigger" data-modal="modal-9">Contact</button>
				</div>
				<div style="border-left:medium #ffffff double; height:300px; margin-left:20%;" />
				<div class="column_mid">
					
					<h2>Dance carnival is just the thing for
you magnificent dancers! Set the stage on fire with your
eloquent flair and dexterity. DANCE CARNIVAL is the ultimate
platform wherein you can showcase your talent and spellbound
the audience with your dexterity!</h2>
				</div>
				<?php include 'rest-footer.php';?>