<?php
echo <<< EOT
<a href="../index.php"><button>Home</button></a>
				<a href="../about.php"><button>About</button></a>
				<a href="../events.php"><button>Events</button></a>
				<a href="../team.php"><button>Team</button></a>
				<a href="../sponsers.php"><button>Sponsors</button></a>
				<a href="../gallery.php"><button>Gallery</button></a>
				<br><br>

EOT;
?>


