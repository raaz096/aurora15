 <?php
echo <<< EOT
						<center><h2>&copy; AURORA`15 - <em>Ensnaring Thy Senses </em>...</h2></center>

<div class="md-overlay"></div><!-- the overlay element -->
<script type='text/javascript' src='js/video.js'></script>
<script src="js/classie.js"></script>
    <script src="js/modalEffects.js"></script>
    <!-- for the blur effect -->
    <!-- by @derSchepp https://github.com/Schepp/CSS-Filters-Polyfill -->
    <script>
      // this is important for IEs
      var polyfilter_scriptpath = '/js/';
    </script>
    <script src="js/cssParser.js"></script>
    <script src="js/css-filters-polyfill.js"></script>

EOT;
?>


