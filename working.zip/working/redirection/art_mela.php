<?php include 'rest-header.php';?>
		<title>Art Mela | Events | Aurora`15</title>
		<div class="md-modal md-effect-1" id="modal-1">
      <div class="md-content">
        <h2>Bits n Chits</h2>
        <div>
          <p>Coming Soon ....</p>
          
          <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
    <div class="md-modal md-effect-2" id="modal-2">
      <div class="md-content">
        <h2>Mehandi</h2>
        <div>
          <p>Coming Soon ....</p>
          <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
    <div class="md-modal md-effect-3" id="modal-3">
      <div class="md-content">
        <h2>Landscape</h2>
        <div>
          <p>Coming Soon ....</p>
            <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
    <div class="md-modal md-effect-1" id="modal-4">
      <div class="md-content">
        <h2>Sketching</h2>
        <div>
          <p>Coming Soon ....</p>
            <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
    <div class="md-modal md-effect-2" id="modal-5">
      <div class="md-content">
        <h2>Face Painting</h2>
        <div>
          <p>Coming Soon ....</p>
            <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
    <div class="md-modal md-effect-3" id="modal-6">
      <div class="md-content">
        <h2>Rangoli</h2>
        <div>
          <p>Coming Soon ....</p>
            <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
    <div class="md-modal md-effect-1" id="modal-7">
      <div class="md-content">
        <h2>Rules</h2>
        <div>
          <p>Coming Soon ....</p>
            <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
    <div class="md-modal md-effect-2" id="modal-8">
      <div class="md-content">
        <h2>Timeline</h2>
        <div>
          <p>Coming Soon ....</p>
            <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
    <div class="md-modal md-effect-3" id="modal-9">
      <div class="md-content">
        <h2>Contact</h2>
        <div>
          <p>Coming Soon ....</p>
            <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
  
		
		<div class="container">
		
			<header>
				<?php include 'rest-navigation.php';?>
				<h1>Art Mela<span><br>Reviving the charismatic arts of 20’s,the Art Mela is a
harmonious fusion of many events like poster- making,
mehendi, rangoli, collage-making, face-painting and
sketching that will entertain you for all the three days
of Aurora 2k15.So fasten your seat belt for the most
colourful ride of the fest and bring out the next M.F
Hussain in you!!</span></h1>
				<button class="md-trigger" data-modal="modal-1">Bits n Chits</button>
					<button class="md-trigger" data-modal="modal-2">Mehandi</button>
					<button class="md-trigger" data-modal="modal-3">Landscape</button>
					<button class="md-trigger" data-modal="modal-4">Sketching</button>
					<button class="md-trigger" data-modal="modal-5">Face Painting</button>
					<button class="md-trigger" data-modal="modal-6">Rangoli</button>
					
							</header>
			<div class="main clearfix">
				<div class="column">
					<br><br><br><br><br>
					<button class="md-trigger" data-modal="modal-7">Rules</button><br>
					<button class="md-trigger" data-modal="modal-8">Timeline</button><br>
					<button class="md-trigger" data-modal="modal-9">Contact</button>
				</div>
				<div style="border-left:medium #ffffff double; height:300px; margin-left:20%;" />
				<div class="column_mid">
					<section class="rw-wrapper">
						<h3 class="rw-sentence">
						<div class="rw-words rw-words-1" style="margin-left:20%;">
							<span>Poster Making</span>
							<span>Rangoli </span>
							<span>Mehandi </span>
							<span>Collage Making</span>
							<span>Face Painting </span>
							<span>Sketching </span>
						</div>
						</h3>
					</section>
          <h2>A cultural fest is incoherent without colors, creativity and
imaginations which fosters the excitement and fun among the
crowd. Bringing to u the similar charm and dazzle from the art
carnivals of India, this event will mesmerize you.
You can win exciting prizes, and make money by sharing your
piece of imagination with us.</h2>
				</div>
		<?php include 'rest-footer.php';?>