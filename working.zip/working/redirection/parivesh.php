<?php include 'cnp-header.php';?>
<title>Parivesh | Events | Aurora`15</title>
<source src="parivesh.webm" type="video/webm">
<source src="parivesh.mp4" type="video/mp4">
</video>
<style type="text/css">
  p{ 	
        font-size: 90%;
        margin: 5%;
        font-weight: 700;
        text-align:left;
        
  }
</style>
<div class="md-modal md-effect-1" id="modal-1">
      <div class="md-content">
        <h1 style="font-size: 190%; color: #93824a;">Rules</h1>
        <p>
        1. Each team can showcase maximum of three rounds.<br>
2. Each team has to register themselves with Rs.400 as the fee.<br>
3. Every team will be given 8:00- 10:00 minutes for each round(stage-in to stage-out).<br>
4. On exceeding the time limit, negative points will be awarded.<br>
5. Each team can have a maximum of 20 members.<br>
6. Every member of the team will be given a contest number based on which his/her judging will be done. So if one loses it he/she will not be given any points.<br>
7. The teams are responsible for their own music and sequence.<br>
8. Music is to be submitted in a pen drive or in a CD in a format compatible with Windows Media player (preferably  in mp3 format). All music files must be submitted to the organizers at least 3 days before the event.<br>
9. Lighting facility is to be availed. One person of the groupcan supervise the lighting; else it will be up to the lights group.<br>
10. Fire and animals in any form will not be allowed on stage or the ramp.<br>
11. Vulgarity in any form will not be allowed in the competition. So if the team feels that any stunt could be termed as vulgar, it would be best to speak of it to the organizer before performing it on t he stage.<br>
12. Organizers reserve the right to cancel any round and disqualify teams which do not adhere to the rules.<br>
13. The decision of the judge will be considered the final one.<br>
<a href="http://aurora15.in/working/redirection/docs/Parivesh.pdf" target="_blank"<strong><h2>For more details click here....</h2></strong></a>
</p>

          
          <button class="md-close">Close me!</button><br>
        
      </div>
    </div>
<div class="md-modal md-effect-2" id="modal-2">
      <div class="md-content">
        <h1 style="font-size: 190%; color: #93824a;">TimeLine</h1>
        <p><b>Coming Soon</b>





</p>

          
          <button class="md-close">Close me!</button><br>
        
      </div>
    </div>
    <div class="md-modal md-effect-3" id="modal-3">
      <div class="md-content">
        <h1 style="font-size: 190%; color: #93824a;">Contact</h1>
        <p>Varun Tandon&thinsp;&thinsp;&thinsp;&thinsp;+91 8817650473</p>

<p>Ravindra Singh&thinsp;&thinsp;&thinsp;&thinsp;+91 7828823889</p>

<p>Madilla Sandesh&thinsp;&thinsp;&thinsp;&thinsp;+91 7725829899</p>
<p> Monika Mahor&thinsp;&thinsp;&thinsp;&thinsp;+91 8982791887</p>

 <p>Anshika Singh&thinsp;&thinsp;&thinsp;&thinsp;+91 9826662062</p>
 <a href="http://aurora15.in/working/redirection/docs/Parivesh.pdf" target="_blank"<strong><h2>For more details click here....</h2></strong></a>
          <br>
          <button class="md-close">Close me!</button><br>
        
      </div>
    </div>
<div id="polina">
 <h1 style="font-size: 250%;">Parivesh </h1>
<h3 style="font-size: 150%;">The Fashion Extravaganza  </h3>
<center>
<style type="text/css">
  h1{text-align: center; 
font-family: 'Droid Sans', sans-serif;
        font-weight: 1000%; 
        font-size: 190%;
        }
</style>
 <a href="#" class="md-trigger" data-modal="modal-1"><h1>Rules |</h1></a>
<a href="#" class="md-trigger" data-modal="modal-2"><h1>Timeline |</h1></a>
<a href="#" class="md-trigger" data-modal="modal-3"><h1>Contact </h1></a>
</center>
<p><strong><em><b>
Beauty is worse than wine, it intoxicates both the
holder and the beholder.</b></em></strong></p>
<p>Glitterati is about to commence and cast its spell upon the
streets of IIITM as young models sashay down the ramp with
panache and allure the hearts of many. PARIVESH-the most
glamorous event of the festival is ready to captivate the
audience with its mesmerizing charm.</p>
<p><b>Come set the stage on fire with your charm and charisma at
Aurora&#8217;15!!!</b></p>

</div>
<h1 style="font-size: 250%;">Events </h1>

<h3 style="font-weight: 1000%; font-size: 150%;">
            
            <a href="../redirection/corna.php">Corna |</a>
            <a href="../redirection/dance_carnival.php">Dance Carnival |</a>
            <a href="../redirection/mnm.php">MnM |</a>
            
            <a href="../redirection/art_mela.php">Art Mela |</a>
            <a href="../redirection/aurora_idol.php">Aurora Idol |</a>

            <a href="../redirection/streetplay.php">Street Play |</a>
            <a href="../redirection/lol.php">Laugh Out Loud |</a>
            <a href="../redirection/treasure_hunt.php">Treasure Hunt |</a>
            <a href="../redirection/phoenix.php">Phoenix</a>
            </h3>
<?php include 'cnp-footer.php';?>
</body>


</html>
