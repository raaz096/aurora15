<?php include 'rest-header.php';?>
		<title>Treasure Hunt | Events | Aurora`15</title>
		<div class="md-modal md-effect-1" id="modal-1">
      <div class="md-content">
        <h2>Rules</h2>
        <div>
          <p>Coming Soon ....</p>
          
          <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
    <div class="md-modal md-effect-2" id="modal-2">
      <div class="md-content">
        <h2>Timeline</h2>
        <div>
          <p>Coming Soon ....</p>
          <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
    <div class="md-modal md-effect-3" id="modal-3">
      <div class="md-content">
        <h2>Contact</h2>
        <div>
          <p>Coming Soon ....</p>
            <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
		
		<div class="container">
			<header>
				<?php include 'rest-navigation.php';?>
				<h1>Treasure Hunt <span><br>"What is the most resilient parasite?" <h2>
Bacteria? A virus? An intestinal worm?</h2> It’s
the thrill of a chase. Resilient... highly
contagious. Once the thrill has taken hold
of the brain it's almost impossible to
eradicate.”</span></h1>
				
			</header>
			<div class="main clearfix">
				<div class="column">
					<br><br><br><br><br>
					<button class="md-trigger" data-modal="modal-1">Rules</button><br>
					<button class="md-trigger" data-modal="modal-2">Timeline</button><br>
					<button class="md-trigger" data-modal="modal-3">Contact</button>
				</div>
				<div style="border-left:medium #ffffff double; height:300px; margin-left:20%;" />
				<div class="column_mid">

					<section class="rw-wrapper">
						<h3 class="rw-sentence">
						<div class="rw-words rw-words-1" style="margin-left:20%;">
							<span>Treasure Hunt </span>
							<span> Street Play </span>
							<span>Laugh Out Loud</span>
							<span>Aurora Idol </span>
							<span>Mr. n Ms. Aurora</span>
							<span>Phoenix </span>
						</div>
						</h3>
					</section>
					<h2>Loaded with a myriad challenges that will
test your thinking and analytical skills to
the limits, Treasure Hunt is coming to open
the doors to a world of wonders that will
keep amazing you at every stage till you
finally reach and unlock the treasure!!!</h2>
				</div>
<?php include 'rest-footer.php';?>
