<?php include 'rest-header.php';?>
		<title>Lough Out Loud | Events | Aurora`15</title>
		<div class="md-modal md-effect-1" id="modal-1">
      <div class="md-content">
        <h2>Rules</h2>
        <div>
          <p>Coming Soon ....</p>
          
          <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
    <div class="md-modal md-effect-2" id="modal-2">
      <div class="md-content">
        <h2>Timeline</h2>
        <div>
          <p>Coming Soon ....</p>
          <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
    <div class="md-modal md-effect-3" id="modal-3">
      <div class="md-content">
        <h2>Contact</h2>
        <div>
          <p>Coming Soon ....</p>
            <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
		
		<div class="container">
			<header>
					<?php include 'rest-navigation.php';?>
					<h1>Laugh Out Loud <span><h2>The only way to survive is to have a sense
of humor.</h2>
When things are difficult, awful, stressful,
the thing that always gets you through is a
sense of humor. From there to here, here to
there, funny things are everywhere. If you
think you have in you what it takes to be
the next Kanan Gill, Aurora2K15 brings to you LOL - The Stand Up Comedy
competition. </span></h1>
			</header>
			<div class="main clearfix">
				<div class="column">
					<br><br><br><br><br>
					<button class="md-trigger" data-modal="modal-1">Rules</button><br>
					<button class="md-trigger" data-modal="modal-2">Timeline</button><br>
					<button class="md-trigger" data-modal="modal-3">Contact</button>
				</div>
				<div style="border-left:medium #ffffff double; height:300px; margin-left:20%;" />
				<div class="column_mid">
					<section class="rw-wrapper">
						<h3 class="rw-sentence">
						<div class="rw-words rw-words-1" style="margin-left:20%;">
							<span>Laugh Out Loud</span>
							<span>Aurora Idol </span>
							<span>Mr. n Ms. Aurora</span>
							<span>Phoenix </span>
							<span>Treasure Hunt </span>
							<span> Street Play </span>
						</div>
						</h3>
					</section>
					<h2> Do you think
you have what it takes? Are there times when all you can think
about is how to make the situation funny? Do you consider
Steve Martin, Jerry Seinfeld, Russell Peters to be your idols? It’s
not easy to go on stage and have people laugh at you, but if
nothing thrills you more, then this competition is for you.</h2>
				</div>
				<?php include 'rest-footer.php';?>
				