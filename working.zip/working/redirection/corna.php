<?php include 'cnp-header.php';?>
<title>Corna | Events | Aurora`15</title>
<source src="corna.webm" type="video/webm">
<source src="corna.mp4" type="video/mp4">
</video>
<style type="text/css">
  p{ 	
        font-size: 90%;
        margin: 5%;
        font-weight: 700;
        text-align:left;
        
  }
</style>
<div class="md-modal md-effect-1" id="modal-1">
      <div class="md-content">
        <h1 style="font-size: 190%; color: #93824a;">Rules</h1>
        <p>1. Purely classical numbers are not allowed. However, a classical refrain is allowed.<br>
2. Obscenity (at the discretion of the judges) of any kind is not allowed and will lead to immediate disqualification.<br>
3. 5 piece drum kit shall be made available by the college.<br>
4. Bands are to bring their own equipment apart from drums which would be arranged by the event manager.<br>
5. Time Limit should be strictly followed. Participants will be penalized by judges for not doing so.<br>
6. The decision of the organizers with respect to line-up would be final.<br>
7. The decision of the judges will be binding.<br>
8. Bands registration fee Rs 2000/- for team upto 5 members. After that, additional Rs 300/- will be charged per member.<br>
9. The fees is non-refundable and includes registration, stay in the campus, food and pick up from railway station/bus stand/airport (the bands must notify beforehand so as to avoid inconvenience).<br>
10. Participants are required to carry their ID cards.
<a href="http://aurora15.in/working/redirection/docs/Corna.pdf" target="_blank"<strong><h2>For more details click here....</h2></strong></a>
</p>

          
          <button class="md-close">Close me!</button><br>
        
      </div>
    </div>
<div class="md-modal md-effect-2" id="modal-2">
      <div class="md-content">
        <h1 style="font-size: 190%; color: #93824a;">TimeLine</h1>
        <p><b>Last Date of Registration-25th January, 2015</b>


<center><strong><p>Team Size:</p></strong></center><p>3-8 members.
At least 1 vocalist and 3 different instruments required (different guitars counted individually), including 1 percussion instrument compulsory.</p>

<center><strong><p>Round(s):</p></strong></center><p>3 (Online, Eliminations, Finals)<br><a href="http://aurora15.in/working/redirection/docs/Corna.pdf" target="_blank"<strong>For more details click here....</strong></a></p>


</p>

          
          <button class="md-close">Close me!</button><br>
        
      </div>
    </div>
    <div class="md-modal md-effect-3" id="modal-3">
      <div class="md-content">
        <h1 style="font-size: 190%; color: #93824a;">Contact</h1>
        <p>Gattu Suryateja &nbsp;&nbsp;&nbsp;&nbsp; 9753946898</p>
	<p>Krishna Kishore &nbsp;&nbsp;&nbsp;&nbsp; 9907723245</p>
	<p>B. Prashant &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;9907723245</p>
	<p>Chaitanya Venkat &nbsp;&nbsp;&nbsp; 9907723245</p>
	<p><a href="http://goo.gl/forms/OdjenQjKst" target="_blank"> Register here - http://goo.gl/forms/OdjenQjKst</a></p>
          <br>
          <button class="md-close">Close me!</button><br>
        
      </div>
    </div>
<div id="polina">
 <h1 style="font-size: 250%;">CORNA </h1>
<h3 style="font-size: 150%;">Rock Band Competition</h3>
<center>
<style type="text/css">
  h1{text-align: center; 
font-family: 'Droid Sans', sans-serif;
        font-weight: 100%; 
        font-size: 150%;}
</style>
 <a href="#" class="md-trigger" data-modal="modal-1"><h1>Rules |</h1></a>
<a href="#" class="md-trigger" data-modal="modal-2"><h1>Timeline |</h1></a>
<a href="#" class="md-trigger" data-modal="modal-3"><h1>Contact |</h1></a>
<a href="http://goo.gl/forms/OdjenQjKst" target="_blank"><h1>Register</h1></a>
</center>
<h3>Recreating the 20&apos;s extravaganza, Corna is all set to rock with the budding Linkin Park and Green Day! </h3>
<p>So sway with the beats and lose yourself to some invigorating music! So come and widen your music space with Corna-The ultimate battle of the bands which will leave you with a musical orgasm never witnessed before. So, come and prove your band prowess and leave your imprints on the minds of an exuberant audience. Corna provides you the supreme platform to test your rock music skills and captivate the hearts of many with your intoxicating music! Corna-the zenith of all band battles keenly awaits you! <h3>Keep rocking your nerves!</h3></p>

</div>
<h1 style="font-size: 250%;">Events </h1>

<h3 style="font-weight: 1000%; font-size: 150%;">
            
            <a href="parivesh.php">Parivesh |</a>
            <a href="dance_carnival.php">Dance Carnival |</a>
            <a href="mnm.php">MnM |</a>
            
            <a href="art_mela.php">Art Mela |</a>
            <a href="aurora_idol.php">Aurora Idol |</a>

            <a href="streetplay.php">Street Play |</a>
            <a href="lol.php">Laugh Out Loud |</a>
            <a href="treasure_hunt.php">Treasure Hunt |</a>
            <a href="phoenix.php">Phoenix</a>
            </h3>
<?php include 'cnp-footer.php';?>
</body>


</html>
