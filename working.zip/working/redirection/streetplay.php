<?php include 'rest-header.php';?>
		<title>Street Play | Events | Aurora`15</title>
		<div class="md-modal md-effect-1" id="modal-1">
      <div class="md-content">
        <h2>Rules</h2>
        <div>
          <p>Coming Soon ....</p>
          
          <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
    <div class="md-modal md-effect-2" id="modal-2">
      <div class="md-content">
        <h2>Timeline</h2>
        <div>
          <p>Coming Soon ....</p>
          <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
    <div class="md-modal md-effect-3" id="modal-3">
      <div class="md-content">
        <h2>Contact</h2>
        <div>
          <p>Coming Soon ....</p>
            <button class="md-close">Close me!</button>
        </div>
      </div>
    </div>
		
		<div class="container">
			<header>
				<?php include 'rest-navigation.php';?>
				<h1>Street Play <span><h2>Movies will make you famous; Television
will make you rich; Theatre will make you
good.</h2>Aurora`15 brings to you right from the
streets, a loud and larger than life
exchange of ideologies with drama full of
drums, catchy songs, humour, energy,
emotions, and the roar of audience. </span></h1>
				
			</header>
			<div class="main clearfix">
				<div class="column">
					<br><br><br><br><br>
					<button class="md-trigger" data-modal="modal-1">Rules</button><br>
					<button class="md-trigger" data-modal="modal-2">Timeline</button><br>
					<button class="md-trigger" data-modal="modal-3">Contact</button>
				</div>
				<div style="border-left:medium #ffffff double; height:300px; margin-left:20%;" />
				<div class="column_mid">

					<section class="rw-wrapper">
						<h3 class="rw-sentence">
						<div class="rw-words rw-words-1" style="margin-left:20%;">
							<span> Street Play </span>
							<span>Laugh Out Loud</span>
							<span>Aurora Idol </span>
							<span>Mr. n Ms. Aurora</span>
							<span>Phoenix </span>
							<span>Treasure Hunt </span>
						</div>
						</h3>
					</section>
					<h2>With energy levels soaring sky high, the atmosphere electric
and the arena as hot as a ball of fire… Groups of people calling
out loud to assemble the crowd, screaming at their lungs’
capacity and ably supported by the beats of the dhol and the
banging of the lathis. </h2>
				</div>
				<?php include 'rest-footer.php';?>