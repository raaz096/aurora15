<?php
echo <<< EOT
<!DOCTYPE html>
<html lang="en-US" class="no-js">
<!-- ************ HEAD START ******************************** -->
<head>
<meta charset="UTF-8"/>
<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
<meta name="viewport" content="width=device-width,initial-scale=1">
<!--favicon-->
<link rel="icon" type="image/ico" href="images/favicon.ico"/>
<!-- ******************************** SCRITPS ******************************** -->
<!--[if lt IE 9]>
<script src="http://bright.acid.themevillage.net/wp-content/themes/acid/js/ie/explorer.js" type="text/javascript"></script>
<link rel="stylesheet" href="http://bright.acid.themevillage.net/wp-content/themes/acid/css/ie.css">
<![endif]-->
<script> ACID_OPTIONS_CONFIG = {"auto_initial_scroll":true}; </script>
<!-- ********************** LINKS and META Tags ******************************** -->
<meta name='robots' content='noindex,follow'/>
				<link href='http://fonts.googleapis.com/css?family=Droid+Sans' rel='stylesheet' type='text/css'>

<link href='http://fonts.googleapis.com/css?family=Merienda' rel='stylesheet' type='text/css'>
<link rel='stylesheet' id='style-css' href='css/style.min.css' type='text/css' media='all'/>
<link rel='stylesheet' id='pure-social-icons-css' href='css/navigation.css' type='text/css' media='all'/>
<link rel="stylesheet" type="text/css" href="css/about_effect.css" />
<!-- ***************************************** SCRIPTS ************************ -->
<script type='text/javascript' src='js/jquery1.11.1.js'></script>
<script type='text/javascript' src='js/jquery-migrate.min.js'></script>
<script src="js/modernizr.custom.72111.js"></script>
<!-- ******************* INTERNAL STYLING START ***************** -->
<style>
.no-cssanimations .rw-wrapper .rw-sentence span:first-child{
	opacity: 1;
}
/*  SECTIONS  */
.section {
	clear: both;
  	padding: 0%;
  	margin: 0%;
}
/*  COLUMN SETUP  */
.col {
  	display: block;
  	float:left;
  	margin: 1% 0 1% 1.6%;
}
.col:first-child { margin-left: 0%; }
/*  GROUPING  */
.group:before,
.group:after {
  	content:"";
  	display:table;
}
.group:after {
  	clear:both;
}
.group {
    zoom:1; /* For IE 6/7 */
}
/*  GRID OF THREE  */
.span_2_of_3 {
  	width: 30%;
}
.span_1_of_3 {
  	width: 60%;
}
/*  GO FULL WIDTH AT LESS THAN 480 PIXELS */
@media only screen and (max-width: 480px) {
  	.col { 
    margin: 1% 0 1% 0%;
  }
}
@media only screen and (max-width: 480px) {
  	.span_2_of_3 {
    width: 100%; 
  }
  	.span_1_of_3 {
    width: 100%;
  }
}
 h3{
	font-style: italic;
	margin: 0;
	padding: 15px 0 5px 0;
	color: white;
			  text-align: center; 
			  font-family: 'Droid Sans', sans-serif; 
			  font-weight: 1000; 
			  font-size: 120%;
			  padding-top: 10px;
			}
h2{
  text-align: center; 
  font-family: 'Droid Sans', sans-serif;
  font-weight: 1000; 
  font-size: 120%;
  color: white;

}
p, h4,  h6, li{
  font-family: 'Merienda', cursive; 
  font-weight: 250; 
  text-align: center;
   color: white;

}
		button {
	padding: 0.6em 1.2em;
background: #95a5a6;
	border-color: #bdc3c7;
		color: #000;
font-family: 'Droid Sans', sans-serif;
	font-size: 1em;
	letter-spacing: 1px;
	text-transform: uppercase;
	cursor: pointer;
	display: inline-block;
	margin: 3px 2px;
	border-radius: 2px;
			  font-family: 'Droid Sans', sans-serif;
			  font-weight: 250%; 
			  font-size:70%;
			  text-align: center;

}

#section {
    width:10%;
    height:10%;
    float:left;
    margin-left :7%;
	margin-top: 3%;	 	 
}
		
		#section_right {
    width:10%;
    float:right;
    height:10%;
    margin-right :8%;
	margin-top: 2%;	 	 
}
		

button:hover {
	background: #bdc3c7;
}

</style>
<!--[if lt IE 9]> 
<style>
.rw-wrapper{ display: none; } 
.rw-sentence-IE{ display: block;  }
</style>
<![endif]-->
<!-- ******************************** INTERNAL STYLING END ********************************-->
</head>
<body style="background-image:url('images/misc.png');>
	<div id="container" class="container">
		<div id="main" class="site-main">
			<div id="next-post" class="static-nav  next-post  js--post-link  hoverable" data-color="#031A21" style="background-color: #2c3e50">
				<div class="meta-container">
					<div class="meta">
						<div class="adjacent-title"><a href="index.php" rel="next">Home</a> </div></div>
						<div class="post-nav-image">
					</div>
				</div>
			</div>
			<div id="prev-post" class="static-nav  prev-post  js--post-link  hoverable" data-color="#031A21" style="background-color: #2c3e50">
				<div class="meta-container">
					<div class="post-nav-image"></div>
					<div class="meta">
						<div class="adjacent-title"><a href="gallery.php" rel="prev">Gallery</a> </div>
					</div>
				</div>
			</div>
			<div id="section"><img src="images/logo.png" width="110%" height="80%"/></div>
		<div id="section_right"><img src="images/iiitmlogo.png" width="80%" height="40%"/></div>
EOT;
?>
