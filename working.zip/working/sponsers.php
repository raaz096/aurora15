<?php include 'spon-header.php';?>

			<section class="main">
			<style>
a:hover {
    color: #93824e;
}

</style>
					<ul class="ch-grid">
						<li>
					<h2><strong>Corna Partner</strong> </h2>
						<img src="https://media.licdn.com/mpr/mpr/shrink_500_500/p/3/000/0f2/395/3146823.jpg"  width="200" height ="200" /><h3><a href="http://numericinfosystems.in/" target="_blank">Numeric Infosystem</a></h3>
					</li>		

					
					<li>
					<h2><strong>Technical Partner</strong> </h2>
						<img src="https://fbcdn-sphotos-h-a.akamaihd.net/hphotos-ak-xpa1/v/t34.0-12/10867138_810822798975843_1869705533_n.jpg?oh=b6a96ed0087d250a17f4e1a79b529f3f&oe=54B8AF2C&__gda__=1421371660_3d6b3a32e1891e31c15a72bf196ac3c8" width="200" height ="200" /><h3><a href="http://www.hackerearth.com/" target="_blank">Hacker Earth</a></h3>
					</li>
					
					
					</ul>
			<ul class="ch-grid">
								<h2><strong>Online Media Partners</strong> </h2>

					<li>
						<img src="http://w3cache.iamwire.com/wp-content/uploads/2013/07/Indiacollage-Search.jpg"  width="150" height="150"/>
					</li>
					<li>
						<img src="http://www.prlog.org/11186890-faadooengineers-logo.png" width="150" height ="150" />
					</li><li>
						<img src="http://iweekend.org/mumbai/files/2013/01/h2e-logo004.jpg" width="150" height ="150" />
					</li>
					<li>
						<img src="https://pbs.twimg.com/profile_images/1389603658/angineer_sign_a_400x400.png" width="150" height ="150" />
					</li>
					<li>
						<img src="https://pbs.twimg.com/profile_images/378800000379042486/1c6ef8698320fd7749b7931ec87e791f_400x400.png" width="150" height ="150" />
					</li>
					<li>
						<img src="http://4.bp.blogspot.com/_KpLZkiIqwn4/S2bdgPUfKoI/AAAAAAAAA-U/hYFLWIwYlyA/s320/250+x+200.png" width="150" height ="150" />
					</li>
					
					
					</ul>
					
					<ul class="ch-grid">
								

					
					<li>
					<h2><strong>Quizzing Partner</strong> </h2>
						<img src="http://d2c-cdn.s3-website-ap-southeast-1.amazonaws.com/images/d2c-logo-v.png" width="200" height ="150" />
					</li>
					
					<li>
					<h2><strong>Messaging Partner</strong> </h2>
						<img src="https://fbcdn-profile-a.akamaihd.net/hprofile-ak-ash2/v/t1.0-1/p160x160/1016296_598987940171866_603935552_n.png?oh=bcc776a595ca9c061c9fbf0afcd98f10&oe=552FC9B7&__gda__=1430014471_4055b665d4ca399f5c2bbad0079be0b2" width="150" height ="150" />
					</li>
					<br><br><br><br><br><br><br><br>
					</ul>
					
			</section>
			
        </div>
        <center><h3><b>&copy; AURORA`15 - <em>Ensnaring Thy Senses </em>...</b></h3></center><br><br>
    </body>
</html>